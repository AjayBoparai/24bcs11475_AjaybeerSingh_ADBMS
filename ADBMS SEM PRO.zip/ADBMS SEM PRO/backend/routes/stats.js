const express = require('express');
const router = express.Router();
const db = require('../db');

// GET /api/stats - Aggregated counts using PostgreSQL COUNT()
router.get('/', async (req, res) => {
    try {
        const result = await db.query(`
            SELECT 
                (SELECT COUNT(*) FROM students) AS students,
                (SELECT COUNT(*) FROM instructors) AS instructors,
                (SELECT COUNT(*) FROM courses) AS courses,
                (SELECT COUNT(*) FROM lessons) AS lessons,
                (SELECT COUNT(*) FROM enrollments) AS enrollments,
                (SELECT COUNT(*) FROM assignments) AS assignments,
                (SELECT COUNT(*) FROM submissions) AS submissions
        `);
        const row = result.rows[0];
        res.json({
            students: parseInt(row.students, 10),
            instructors: parseInt(row.instructors, 10),
            courses: parseInt(row.courses, 10),
            lessons: parseInt(row.lessons, 10),
            enrollments: parseInt(row.enrollments, 10),
            assignments: parseInt(row.assignments, 10),
            submissions: parseInt(row.submissions, 10),
        });
    } catch (err) {
        console.error('Error fetching stats:', err);
        res.status(500).json({ error: 'Failed to fetch database statistics', details: err.message });
    }
});

module.exports = router;
