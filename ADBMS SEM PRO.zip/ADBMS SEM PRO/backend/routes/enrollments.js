const express = require('express');
const router = express.Router();
const db = require('../db');

// GET /api/enrollments - List all enrollments with student name and course name (via JOINs)
router.get('/', async (req, res) => {
    try {
        const query = `
            SELECT 
                e.enrollment_id,
                e.student_id,
                s.name AS student_name,
                s.email AS student_email,
                e.course_id,
                c.course_name,
                TO_CHAR(e.enrollment_date, 'YYYY-MM-DD') AS enrollment_date,
                e.progress
            FROM enrollments e
            JOIN students s ON e.student_id = s.student_id
            JOIN courses c ON e.course_id = c.course_id
            ORDER BY e.enrollment_id ASC
        `;
        const result = await db.query(query);
        res.json(result.rows);
    } catch (err) {
        console.error('Error fetching enrollments:', err);
        res.status(500).json({ error: 'Failed to fetch enrollments', details: err.message });
    }
});

// GET /api/enrollments/:id - Get single enrollment
router.get('/:id', async (req, res) => {
    try {
        const { id } = req.params;
        const query = `
            SELECT 
                e.enrollment_id,
                e.student_id,
                s.name AS student_name,
                e.course_id,
                c.course_name,
                TO_CHAR(e.enrollment_date, 'YYYY-MM-DD') AS enrollment_date,
                e.progress
            FROM enrollments e
            JOIN students s ON e.student_id = s.student_id
            JOIN courses c ON e.course_id = c.course_id
            WHERE e.enrollment_id = $1
        `;
        const result = await db.query(query, [id]);
        if (result.rows.length === 0) {
            return res.status(404).json({ error: 'Enrollment not found' });
        }
        res.json(result.rows[0]);
    } catch (err) {
        console.error('Error fetching enrollment:', err);
        res.status(500).json({ error: 'Failed to fetch enrollment', details: err.message });
    }
});

// POST /api/enrollments - Enroll student in course
router.post('/', async (req, res) => {
    try {
        const { student_id, course_id, enrollment_date, progress } = req.body;
        if (!student_id || !course_id) {
            return res.status(400).json({ error: 'Student and Course are required.' });
        }
        const progVal = progress !== undefined && progress !== '' ? parseInt(progress, 10) : 0;
        const dateVal = enrollment_date || new Date().toISOString().split('T')[0];

        const query = `
            INSERT INTO enrollments (student_id, course_id, enrollment_date, progress)
            VALUES ($1, $2, $3, $4)
            RETURNING *
        `;
        const result = await db.query(query, [parseInt(student_id, 10), parseInt(course_id, 10), dateVal, progVal]);
        res.status(201).json(result.rows[0]);
    } catch (err) {
        console.error('Error creating enrollment:', err);
        if (err.code === '23505') {
            return res.status(409).json({ error: 'This student is already enrolled in this course (UNIQUE constraint violation).' });
        }
        if (err.code === '23503') {
            return res.status(400).json({ error: 'Invalid Student ID or Course ID specified.' });
        }
        if (err.code === '23514' || err.code === 'P0001') {
            return res.status(400).json({ error: err.message || 'Progress must be between 0 and 100.' });
        }
        res.status(500).json({ error: 'Failed to create enrollment', details: err.message });
    }
});

// PUT /api/enrollments/:id - Update enrollment
router.put('/:id', async (req, res) => {
    try {
        const { id } = req.params;
        const { student_id, course_id, enrollment_date, progress } = req.body;
        if (!student_id || !course_id) {
            return res.status(400).json({ error: 'Student and Course are required.' });
        }
        const progVal = progress !== undefined && progress !== '' ? parseInt(progress, 10) : 0;
        const dateVal = enrollment_date || new Date().toISOString().split('T')[0];

        const query = `
            UPDATE enrollments
            SET student_id = $1, course_id = $2, enrollment_date = $3, progress = $4
            WHERE enrollment_id = $5
            RETURNING *
        `;
        const result = await db.query(query, [parseInt(student_id, 10), parseInt(course_id, 10), dateVal, progVal, id]);
        if (result.rows.length === 0) {
            return res.status(404).json({ error: 'Enrollment not found' });
        }
        res.json(result.rows[0]);
    } catch (err) {
        console.error('Error updating enrollment:', err);
        if (err.code === '23505') {
            return res.status(409).json({ error: 'This student is already enrolled in this course (UNIQUE constraint violation).' });
        }
        if (err.code === '23503') {
            return res.status(400).json({ error: 'Invalid Student ID or Course ID specified.' });
        }
        if (err.code === '23514' || err.code === 'P0001') {
            return res.status(400).json({ error: err.message || 'Progress must be between 0 and 100.' });
        }
        res.status(500).json({ error: 'Failed to update enrollment', details: err.message });
    }
});

// DELETE /api/enrollments/:id - Delete enrollment
router.delete('/:id', async (req, res) => {
    try {
        const { id } = req.params;
        const result = await db.query('DELETE FROM enrollments WHERE enrollment_id = $1 RETURNING *', [id]);
        if (result.rows.length === 0) {
            return res.status(404).json({ error: 'Enrollment not found' });
        }
        res.json({ message: 'Enrollment deleted successfully', deleted: result.rows[0] });
    } catch (err) {
        console.error('Error deleting enrollment:', err);
        res.status(500).json({ error: 'Failed to delete enrollment', details: err.message });
    }
});

module.exports = router;
