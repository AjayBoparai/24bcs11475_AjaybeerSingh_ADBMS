const express = require('express');
const router = express.Router();
const db = require('../db');

// Registered SQL queries for live demonstration in viva/ADBMS
const demoQueries = [
    {
        id: 1,
        title: 'Basic SELECT: All Students',
        sql: `SELECT student_id, name, email, phone, department, semester FROM students ORDER BY name ASC;`,
        concept: 'Basic Projection & Ordering'
    },
    {
        id: 2,
        title: 'INNER JOIN: Courses with Instructor Details',
        sql: `SELECT c.course_id, c.course_name, c.category, i.name AS instructor_name, i.email AS instructor_email, i.department AS instructor_department FROM courses c INNER JOIN instructors i ON c.instructor_id = i.instructor_id ORDER BY c.course_id;`,
        concept: '1:N Relationship Navigation (INNER JOIN)'
    },
    {
        id: 3,
        title: 'Multi-Table INNER JOIN: Student Enrollments',
        sql: `SELECT s.student_id, s.name AS student_name, c.course_id, c.course_name, e.enrollment_date, e.progress || '%' AS progress FROM enrollments e INNER JOIN students s ON e.student_id = s.student_id INNER JOIN courses c ON e.course_id = c.course_id ORDER BY c.course_name, s.name;`,
        concept: 'N:M Relationship Resolution via Bridge Table'
    },
    {
        id: 4,
        title: 'GROUP BY & COUNT(): Course-Wise Enrolled Students',
        sql: `SELECT c.course_id, c.course_name, COUNT(e.student_id) AS total_enrolled_students FROM courses c LEFT JOIN enrollments e ON c.course_id = e.course_id GROUP BY c.course_id, c.course_name ORDER BY total_enrolled_students DESC;`,
        concept: 'Aggregation (COUNT with GROUP BY)'
    },
    {
        id: 5,
        title: 'AVG() & GROUP BY: Course Average Progress',
        sql: `SELECT c.course_id, c.course_name, ROUND(AVG(e.progress), 2) AS average_progress_percentage FROM courses c JOIN enrollments e ON c.course_id = e.course_id GROUP BY c.course_id, c.course_name ORDER BY average_progress_percentage DESC;`,
        concept: 'Statistical Aggregation (AVG with GROUP BY)'
    },
    {
        id: 6,
        title: 'WHERE Clause: Students with Progress > 50%',
        sql: `SELECT s.name AS student_name, c.course_name, e.progress FROM enrollments e JOIN students s ON e.student_id = s.student_id JOIN courses c ON e.course_id = c.course_id WHERE e.progress > 50 ORDER BY e.progress DESC;`,
        concept: 'Conditional Filtering with WHERE'
    },
    {
        id: 7,
        title: 'JOIN: Assignments with Associated Course',
        sql: `SELECT a.assignment_id, a.title AS assignment_title, c.course_name, a.due_date, a.max_marks FROM assignments a JOIN courses c ON a.course_id = c.course_id ORDER BY a.due_date ASC;`,
        concept: 'Referential Integrity & JOIN'
    },
    {
        id: 8,
        title: 'Multiple JOINs: Student Assignment Scores',
        sql: `SELECT sub.submission_id, s.name AS student_name, c.course_name, a.title AS assignment_title, sub.marks AS marks_obtained, a.max_marks, ROUND((sub.marks::NUMERIC / a.max_marks::NUMERIC) * 100, 2) AS percentage_score FROM submissions sub JOIN assignments a ON sub.assignment_id = a.assignment_id JOIN courses c ON a.course_id = c.course_id JOIN students s ON sub.student_id = s.student_id ORDER BY sub.submission_id;`,
        concept: 'Complex 4-Table Relationship Joining'
    },
    {
        id: 9,
        title: 'MAX(), MIN(), AVG(): Assignment Score Benchmarks',
        sql: `SELECT a.assignment_id, a.title AS assignment_title, a.max_marks, MAX(sub.marks) AS highest_marks, MIN(sub.marks) AS lowest_marks, ROUND(AVG(sub.marks), 2) AS average_marks, COUNT(sub.submission_id) AS total_submissions FROM assignments a JOIN submissions sub ON a.assignment_id = sub.assignment_id GROUP BY a.assignment_id, a.title, a.max_marks;`,
        concept: 'Multiple Aggregate Functions'
    },
    {
        id: 10,
        title: 'GROUP BY: Total Lessons per Course',
        sql: `SELECT c.course_id, c.course_name, COUNT(l.lesson_id) AS total_lessons FROM courses c LEFT JOIN lessons l ON c.course_id = l.course_id GROUP BY c.course_id, c.course_name ORDER BY c.course_id;`,
        concept: 'LEFT JOIN with Aggregate Count'
    },
    {
        id: 11,
        title: 'LEFT JOIN: Students Not Enrolled in Any Course',
        sql: `SELECT s.student_id, s.name AS student_name, s.email, s.department FROM students s LEFT JOIN enrollments e ON s.student_id = e.student_id WHERE e.enrollment_id IS NULL;`,
        concept: 'Anti-Join using LEFT OUTER JOIN & IS NULL'
    },
    {
        id: 12,
        title: 'HAVING Clause: Courses with More Than 2 Students',
        sql: `SELECT c.course_id, c.course_name, COUNT(e.student_id) AS student_count FROM courses c JOIN enrollments e ON c.course_id = e.course_id GROUP BY c.course_id, c.course_name HAVING COUNT(e.student_id) > 2;`,
        concept: 'Aggregated Group Filtering (HAVING)'
    },
    {
        id: 13,
        title: 'Nested Subquery: Courses Above Average Enrollment',
        sql: `SELECT c.course_id, c.course_name, COUNT(e.student_id) AS enrollment_count FROM courses c JOIN enrollments e ON c.course_id = e.course_id GROUP BY c.course_id, c.course_name HAVING COUNT(e.student_id) > (SELECT AVG(course_counts.cnt) FROM (SELECT COUNT(student_id) AS cnt FROM enrollments GROUP BY course_id) AS course_counts);`,
        concept: 'Subqueries & Derived Tables'
    },
    {
        id: 14,
        title: 'ADBMS View: course_enrollment_details',
        sql: `SELECT course_name, instructor, student, TO_CHAR(enrollment_date, 'YYYY-MM-DD') AS enrollment_date, progress FROM course_enrollment_details ORDER BY course_name, student;`,
        concept: 'Database VIEW (Virtual Table)'
    },
    {
        id: 15,
        title: 'ADBMS Stored Function: get_course_enrollment_count()',
        sql: `SELECT course_id, course_name, get_course_enrollment_count(course_id) AS active_enrollments FROM courses ORDER BY active_enrollments DESC;`,
        concept: 'PL/pgSQL Stored Function'
    }
];

// GET /api/queries - Return list of available demo queries
router.get('/', (req, res) => {
    res.json(demoQueries.map(q => ({ id: q.id, title: q.title, concept: q.concept, sql: q.sql })));
});

// GET /api/queries/run/:id - Execute a specific demo query
router.get('/run/:id', async (req, res) => {
    const id = parseInt(req.params.id, 10);
    const queryItem = demoQueries.find(q => q.id === id);
    if (!queryItem) {
        return res.status(404).json({ error: 'Query ID not found.' });
    }

    try {
        const result = await db.query(queryItem.sql);
        res.json({
            id: queryItem.id,
            title: queryItem.title,
            concept: queryItem.concept,
            sql: queryItem.sql,
            rowCount: result.rows.length,
            rows: result.rows
        });
    } catch (err) {
        console.error('Error running demo query:', err);
        res.status(500).json({ error: 'Failed to run query', details: err.message });
    }
});

// GET /api/view/course-enrollments - Query the ADBMS view directly
router.get('/view/course-enrollments', async (req, res) => {
    try {
        const query = `
            SELECT 
                course_name, 
                instructor, 
                student, 
                TO_CHAR(enrollment_date, 'YYYY-MM-DD') AS enrollment_date, 
                progress 
            FROM course_enrollment_details 
            ORDER BY course_name, student
        `;
        const result = await db.query(query);
        res.json(result.rows);
    } catch (err) {
        console.error('Error querying view:', err);
        res.status(500).json({ error: 'Failed to query course_enrollment_details view', details: err.message });
    }
});

module.exports = router;
