const express = require('express');
const router = express.Router();
const db = require('../db');

// GET /api/courses - List all courses with instructor name (via INNER JOIN)
router.get('/', async (req, res) => {
    try {
        const query = `
            SELECT 
                c.course_id,
                c.course_name,
                c.description,
                c.category,
                c.instructor_id,
                i.name AS instructor_name,
                i.email AS instructor_email
            FROM courses c
            JOIN instructors i ON c.instructor_id = i.instructor_id
            ORDER BY c.course_id ASC
        `;
        const result = await db.query(query);
        res.json(result.rows);
    } catch (err) {
        console.error('Error fetching courses:', err);
        res.status(500).json({ error: 'Failed to fetch courses', details: err.message });
    }
});

// GET /api/courses/:id - Get single course
router.get('/:id', async (req, res) => {
    try {
        const { id } = req.params;
        const query = `
            SELECT 
                c.course_id,
                c.course_name,
                c.description,
                c.category,
                c.instructor_id,
                i.name AS instructor_name
            FROM courses c
            JOIN instructors i ON c.instructor_id = i.instructor_id
            WHERE c.course_id = $1
        `;
        const result = await db.query(query, [id]);
        if (result.rows.length === 0) {
            return res.status(404).json({ error: 'Course not found' });
        }
        res.json(result.rows[0]);
    } catch (err) {
        console.error('Error fetching course:', err);
        res.status(500).json({ error: 'Failed to fetch course', details: err.message });
    }
});

// POST /api/courses - Add course
router.post('/', async (req, res) => {
    try {
        const { course_name, description, category, instructor_id } = req.body;
        if (!course_name || !category || !instructor_id) {
            return res.status(400).json({ error: 'Course name, category, and instructor are required.' });
        }
        const query = `
            INSERT INTO courses (course_name, description, category, instructor_id)
            VALUES ($1, $2, $3, $4)
            RETURNING *
        `;
        const result = await db.query(query, [course_name, description || null, category, parseInt(instructor_id, 10)]);
        res.status(201).json(result.rows[0]);
    } catch (err) {
        console.error('Error adding course:', err);
        if (err.code === '23503') {
            return res.status(400).json({ error: 'Selected instructor does not exist.' });
        }
        res.status(500).json({ error: 'Failed to add course', details: err.message });
    }
});

// PUT /api/courses/:id - Update course
router.put('/:id', async (req, res) => {
    try {
        const { id } = req.params;
        const { course_name, description, category, instructor_id } = req.body;
        if (!course_name || !category || !instructor_id) {
            return res.status(400).json({ error: 'Course name, category, and instructor are required.' });
        }
        const query = `
            UPDATE courses
            SET course_name = $1, description = $2, category = $3, instructor_id = $4
            WHERE course_id = $5
            RETURNING *
        `;
        const result = await db.query(query, [course_name, description || null, category, parseInt(instructor_id, 10), id]);
        if (result.rows.length === 0) {
            return res.status(404).json({ error: 'Course not found' });
        }
        res.json(result.rows[0]);
    } catch (err) {
        console.error('Error updating course:', err);
        if (err.code === '23503') {
            return res.status(400).json({ error: 'Selected instructor does not exist.' });
        }
        res.status(500).json({ error: 'Failed to update course', details: err.message });
    }
});

// DELETE /api/courses/:id - Delete course
router.delete('/:id', async (req, res) => {
    try {
        const { id } = req.params;
        const result = await db.query('DELETE FROM courses WHERE course_id = $1 RETURNING *', [id]);
        if (result.rows.length === 0) {
            return res.status(404).json({ error: 'Course not found' });
        }
        res.json({ message: 'Course deleted successfully', deleted: result.rows[0] });
    } catch (err) {
        console.error('Error deleting course:', err);
        res.status(500).json({ error: 'Failed to delete course', details: err.message });
    }
});

module.exports = router;
