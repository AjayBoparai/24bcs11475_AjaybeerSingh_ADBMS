const express = require('express');
const router = express.Router();
const db = require('../db');

// GET /api/assignments - List all assignments with course name (via JOIN)
router.get('/', async (req, res) => {
    try {
        const query = `
            SELECT 
                a.assignment_id,
                a.course_id,
                c.course_name,
                a.title,
                a.description,
                TO_CHAR(a.due_date, 'YYYY-MM-DD') AS due_date,
                a.max_marks
            FROM assignments a
            JOIN courses c ON a.course_id = c.course_id
            ORDER BY a.assignment_id ASC
        `;
        const result = await db.query(query);
        res.json(result.rows);
    } catch (err) {
        console.error('Error fetching assignments:', err);
        res.status(500).json({ error: 'Failed to fetch assignments', details: err.message });
    }
});

// GET /api/assignments/:id - Get single assignment
router.get('/:id', async (req, res) => {
    try {
        const { id } = req.params;
        const query = `
            SELECT 
                a.assignment_id,
                a.course_id,
                c.course_name,
                a.title,
                a.description,
                TO_CHAR(a.due_date, 'YYYY-MM-DD') AS due_date,
                a.max_marks
            FROM assignments a
            JOIN courses c ON a.course_id = c.course_id
            WHERE a.assignment_id = $1
        `;
        const result = await db.query(query, [id]);
        if (result.rows.length === 0) {
            return res.status(404).json({ error: 'Assignment not found' });
        }
        res.json(result.rows[0]);
    } catch (err) {
        console.error('Error fetching assignment:', err);
        res.status(500).json({ error: 'Failed to fetch assignment', details: err.message });
    }
});

// POST /api/assignments - Add assignment
router.post('/', async (req, res) => {
    try {
        const { course_id, title, description, due_date, max_marks } = req.body;
        if (!course_id || !title || !due_date || !max_marks) {
            return res.status(400).json({ error: 'Course, title, due date, and max marks are required.' });
        }
        const query = `
            INSERT INTO assignments (course_id, title, description, due_date, max_marks)
            VALUES ($1, $2, $3, $4, $5)
            RETURNING *
        `;
        const result = await db.query(query, [
            parseInt(course_id, 10),
            title,
            description || null,
            due_date,
            parseInt(max_marks, 10),
        ]);
        res.status(201).json(result.rows[0]);
    } catch (err) {
        console.error('Error adding assignment:', err);
        if (err.code === '23503') {
            return res.status(400).json({ error: 'Selected course does not exist.' });
        }
        if (err.code === '23514') {
            return res.status(400).json({ error: 'Maximum marks must be greater than 0.' });
        }
        res.status(500).json({ error: 'Failed to add assignment', details: err.message });
    }
});

// PUT /api/assignments/:id - Update assignment
router.put('/:id', async (req, res) => {
    try {
        const { id } = req.params;
        const { course_id, title, description, due_date, max_marks } = req.body;
        if (!course_id || !title || !due_date || !max_marks) {
            return res.status(400).json({ error: 'Course, title, due date, and max marks are required.' });
        }
        const query = `
            UPDATE assignments
            SET course_id = $1, title = $2, description = $3, due_date = $4, max_marks = $5
            WHERE assignment_id = $6
            RETURNING *
        `;
        const result = await db.query(query, [
            parseInt(course_id, 10),
            title,
            description || null,
            due_date,
            parseInt(max_marks, 10),
            id,
        ]);
        if (result.rows.length === 0) {
            return res.status(404).json({ error: 'Assignment not found' });
        }
        res.json(result.rows[0]);
    } catch (err) {
        console.error('Error updating assignment:', err);
        if (err.code === '23503') {
            return res.status(400).json({ error: 'Selected course does not exist.' });
        }
        if (err.code === '23514') {
            return res.status(400).json({ error: 'Maximum marks must be greater than 0.' });
        }
        res.status(500).json({ error: 'Failed to update assignment', details: err.message });
    }
});

// DELETE /api/assignments/:id - Delete assignment
router.delete('/:id', async (req, res) => {
    try {
        const { id } = req.params;
        const result = await db.query('DELETE FROM assignments WHERE assignment_id = $1 RETURNING *', [id]);
        if (result.rows.length === 0) {
            return res.status(404).json({ error: 'Assignment not found' });
        }
        res.json({ message: 'Assignment deleted successfully', deleted: result.rows[0] });
    } catch (err) {
        console.error('Error deleting assignment:', err);
        res.status(500).json({ error: 'Failed to delete assignment', details: err.message });
    }
});

module.exports = router;
