const express = require('express');
const router = express.Router();
const db = require('../db');

// GET /api/instructors - List all instructors
router.get('/', async (req, res) => {
    try {
        const result = await db.query('SELECT * FROM instructors ORDER BY instructor_id ASC');
        res.json(result.rows);
    } catch (err) {
        console.error('Error fetching instructors:', err);
        res.status(500).json({ error: 'Failed to fetch instructors', details: err.message });
    }
});

// GET /api/instructors/:id - Get single instructor
router.get('/:id', async (req, res) => {
    try {
        const { id } = req.params;
        const result = await db.query('SELECT * FROM instructors WHERE instructor_id = $1', [id]);
        if (result.rows.length === 0) {
            return res.status(404).json({ error: 'Instructor not found' });
        }
        res.json(result.rows[0]);
    } catch (err) {
        console.error('Error fetching instructor:', err);
        res.status(500).json({ error: 'Failed to fetch instructor', details: err.message });
    }
});

// POST /api/instructors - Add new instructor
router.post('/', async (req, res) => {
    try {
        const { name, email, department } = req.body;
        if (!name || !email || !department) {
            return res.status(400).json({ error: 'Name, email, and department are required.' });
        }
        const query = `
            INSERT INTO instructors (name, email, department)
            VALUES ($1, $2, $3)
            RETURNING *
        `;
        const result = await db.query(query, [name, email, department]);
        res.status(201).json(result.rows[0]);
    } catch (err) {
        console.error('Error adding instructor:', err);
        if (err.code === '23505') {
            return res.status(409).json({ error: 'An instructor with this email already exists.' });
        }
        res.status(500).json({ error: 'Failed to add instructor', details: err.message });
    }
});

// PUT /api/instructors/:id - Update instructor
router.put('/:id', async (req, res) => {
    try {
        const { id } = req.params;
        const { name, email, department } = req.body;
        if (!name || !email || !department) {
            return res.status(400).json({ error: 'Name, email, and department are required.' });
        }
        const query = `
            UPDATE instructors
            SET name = $1, email = $2, department = $3
            WHERE instructor_id = $4
            RETURNING *
        `;
        const result = await db.query(query, [name, email, department, id]);
        if (result.rows.length === 0) {
            return res.status(404).json({ error: 'Instructor not found' });
        }
        res.json(result.rows[0]);
    } catch (err) {
        console.error('Error updating instructor:', err);
        if (err.code === '23505') {
            return res.status(409).json({ error: 'An instructor with this email already exists.' });
        }
        res.status(500).json({ error: 'Failed to update instructor', details: err.message });
    }
});

// DELETE /api/instructors/:id - Delete instructor
router.delete('/:id', async (req, res) => {
    try {
        const { id } = req.params;
        const result = await db.query('DELETE FROM instructors WHERE instructor_id = $1 RETURNING *', [id]);
        if (result.rows.length === 0) {
            return res.status(404).json({ error: 'Instructor not found' });
        }
        res.json({ message: 'Instructor deleted successfully', deleted: result.rows[0] });
    } catch (err) {
        console.error('Error deleting instructor:', err);
        if (err.code === '23503') {
            return res.status(409).json({ error: 'Cannot delete instructor who is currently assigned to courses.' });
        }
        res.status(500).json({ error: 'Failed to delete instructor', details: err.message });
    }
});

module.exports = router;
