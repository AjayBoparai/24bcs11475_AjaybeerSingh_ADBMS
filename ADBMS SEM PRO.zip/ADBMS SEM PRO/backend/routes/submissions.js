const express = require('express');
const router = express.Router();
const db = require('../db');

// GET /api/submissions - List all submissions with student and assignment names (via JOINs)
router.get('/', async (req, res) => {
    try {
        const query = `
            SELECT 
                sub.submission_id,
                sub.student_id,
                s.name AS student_name,
                sub.assignment_id,
                a.title AS assignment_title,
                c.course_name,
                TO_CHAR(sub.submission_date, 'YYYY-MM-DD') AS submission_date,
                sub.marks,
                a.max_marks
            FROM submissions sub
            JOIN students s ON sub.student_id = s.student_id
            JOIN assignments a ON sub.assignment_id = a.assignment_id
            JOIN courses c ON a.course_id = c.course_id
            ORDER BY sub.submission_id ASC
        `;
        const result = await db.query(query);
        res.json(result.rows);
    } catch (err) {
        console.error('Error fetching submissions:', err);
        res.status(500).json({ error: 'Failed to fetch submissions', details: err.message });
    }
});

// GET /api/submissions/:id - Get single submission
router.get('/:id', async (req, res) => {
    try {
        const { id } = req.params;
        const query = `
            SELECT 
                sub.submission_id,
                sub.student_id,
                s.name AS student_name,
                sub.assignment_id,
                a.title AS assignment_title,
                c.course_name,
                TO_CHAR(sub.submission_date, 'YYYY-MM-DD') AS submission_date,
                sub.marks,
                a.max_marks
            FROM submissions sub
            JOIN students s ON sub.student_id = s.student_id
            JOIN assignments a ON sub.assignment_id = a.assignment_id
            JOIN courses c ON a.course_id = c.course_id
            WHERE sub.submission_id = $1
        `;
        const result = await db.query(query, [id]);
        if (result.rows.length === 0) {
            return res.status(404).json({ error: 'Submission not found' });
        }
        res.json(result.rows[0]);
    } catch (err) {
        console.error('Error fetching submission:', err);
        res.status(500).json({ error: 'Failed to fetch submission', details: err.message });
    }
});

// POST /api/submissions - Add submission
router.post('/', async (req, res) => {
    try {
        const { assignment_id, student_id, submission_date, marks } = req.body;
        if (!assignment_id || !student_id) {
            return res.status(400).json({ error: 'Assignment and Student are required.' });
        }
        const marksVal = marks !== undefined && marks !== '' ? parseInt(marks, 10) : null;
        const dateVal = submission_date || new Date().toISOString().split('T')[0];

        const query = `
            INSERT INTO submissions (assignment_id, student_id, submission_date, marks)
            VALUES ($1, $2, $3, $4)
            RETURNING *
        `;
        const result = await db.query(query, [parseInt(assignment_id, 10), parseInt(student_id, 10), dateVal, marksVal]);
        res.status(201).json(result.rows[0]);
    } catch (err) {
        console.error('Error adding submission:', err);
        if (err.code === '23505') {
            return res.status(409).json({ error: 'This student has already submitted this assignment.' });
        }
        if (err.code === '23503') {
            return res.status(400).json({ error: 'Invalid Student ID or Assignment ID.' });
        }
        if (err.code === '23514') {
            return res.status(400).json({ error: 'Marks must be greater than or equal to 0.' });
        }
        res.status(500).json({ error: 'Failed to add submission', details: err.message });
    }
});

// PUT /api/submissions/:id - Update submission
router.put('/:id', async (req, res) => {
    try {
        const { id } = req.params;
        const { assignment_id, student_id, submission_date, marks } = req.body;
        if (!assignment_id || !student_id) {
            return res.status(400).json({ error: 'Assignment and Student are required.' });
        }
        const marksVal = marks !== undefined && marks !== '' ? parseInt(marks, 10) : null;
        const dateVal = submission_date || new Date().toISOString().split('T')[0];

        const query = `
            UPDATE submissions
            SET assignment_id = $1, student_id = $2, submission_date = $3, marks = $4
            WHERE submission_id = $5
            RETURNING *
        `;
        const result = await db.query(query, [parseInt(assignment_id, 10), parseInt(student_id, 10), dateVal, marksVal, id]);
        if (result.rows.length === 0) {
            return res.status(404).json({ error: 'Submission not found' });
        }
        res.json(result.rows[0]);
    } catch (err) {
        console.error('Error updating submission:', err);
        if (err.code === '23505') {
            return res.status(409).json({ error: 'This student has already submitted this assignment.' });
        }
        if (err.code === '23503') {
            return res.status(400).json({ error: 'Invalid Student ID or Assignment ID.' });
        }
        if (err.code === '23514') {
            return res.status(400).json({ error: 'Marks must be greater than or equal to 0.' });
        }
        res.status(500).json({ error: 'Failed to update submission', details: err.message });
    }
});

// DELETE /api/submissions/:id - Delete submission
router.delete('/:id', async (req, res) => {
    try {
        const { id } = req.params;
        const result = await db.query('DELETE FROM submissions WHERE submission_id = $1 RETURNING *', [id]);
        if (result.rows.length === 0) {
            return res.status(404).json({ error: 'Submission not found' });
        }
        res.json({ message: 'Submission deleted successfully', deleted: result.rows[0] });
    } catch (err) {
        console.error('Error deleting submission:', err);
        res.status(500).json({ error: 'Failed to delete submission', details: err.message });
    }
});

module.exports = router;
