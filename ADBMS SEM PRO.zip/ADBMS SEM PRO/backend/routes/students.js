const express = require('express');
const router = express.Router();
const db = require('../db');

// GET /api/students - List all students
router.get('/', async (req, res) => {
    try {
        const result = await db.query('SELECT * FROM students ORDER BY student_id ASC');
        res.json(result.rows);
    } catch (err) {
        console.error('Error fetching students:', err);
        res.status(500).json({ error: 'Failed to fetch students', details: err.message });
    }
});

// GET /api/students/:id - Get single student
router.get('/:id', async (req, res) => {
    try {
        const { id } = req.params;
        const result = await db.query('SELECT * FROM students WHERE student_id = $1', [id]);
        if (result.rows.length === 0) {
            return res.status(404).json({ error: 'Student not found' });
        }
        res.json(result.rows[0]);
    } catch (err) {
        console.error('Error fetching student:', err);
        res.status(500).json({ error: 'Failed to fetch student', details: err.message });
    }
});

// POST /api/students - Add new student
router.post('/', async (req, res) => {
    try {
        const { name, email, phone, department, semester } = req.body;
        if (!name || !email || !department || !semester) {
            return res.status(400).json({ error: 'Name, email, department, and semester are required.' });
        }
        const query = `
            INSERT INTO students (name, email, phone, department, semester)
            VALUES ($1, $2, $3, $4, $5)
            RETURNING *
        `;
        const result = await db.query(query, [name, email, phone || null, department, parseInt(semester, 10)]);
        res.status(201).json(result.rows[0]);
    } catch (err) {
        console.error('Error adding student:', err);
        if (err.code === '23505') {
            return res.status(409).json({ error: 'A student with this email already exists.' });
        }
        res.status(500).json({ error: 'Failed to add student', details: err.message });
    }
});

// PUT /api/students/:id - Update student
router.put('/:id', async (req, res) => {
    try {
        const { id } = req.params;
        const { name, email, phone, department, semester } = req.body;
        if (!name || !email || !department || !semester) {
            return res.status(400).json({ error: 'Name, email, department, and semester are required.' });
        }
        const query = `
            UPDATE students 
            SET name = $1, email = $2, phone = $3, department = $4, semester = $5
            WHERE student_id = $6
            RETURNING *
        `;
        const result = await db.query(query, [name, email, phone || null, department, parseInt(semester, 10), id]);
        if (result.rows.length === 0) {
            return res.status(404).json({ error: 'Student not found' });
        }
        res.json(result.rows[0]);
    } catch (err) {
        console.error('Error updating student:', err);
        if (err.code === '23505') {
            return res.status(409).json({ error: 'A student with this email already exists.' });
        }
        res.status(500).json({ error: 'Failed to update student', details: err.message });
    }
});

// DELETE /api/students/:id - Delete student
router.delete('/:id', async (req, res) => {
    try {
        const { id } = req.params;
        const result = await db.query('DELETE FROM students WHERE student_id = $1 RETURNING *', [id]);
        if (result.rows.length === 0) {
            return res.status(404).json({ error: 'Student not found' });
        }
        res.json({ message: 'Student deleted successfully', deleted: result.rows[0] });
    } catch (err) {
        console.error('Error deleting student:', err);
        res.status(500).json({ error: 'Failed to delete student', details: err.message });
    }
});

module.exports = router;
