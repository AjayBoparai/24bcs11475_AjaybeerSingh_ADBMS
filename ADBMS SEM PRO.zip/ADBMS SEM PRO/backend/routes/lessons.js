const express = require('express');
const router = express.Router();
const db = require('../db');

// GET /api/lessons - List all lessons with course name (via JOIN)
router.get('/', async (req, res) => {
    try {
        const query = `
            SELECT 
                l.lesson_id,
                l.course_id,
                c.course_name,
                l.lesson_number,
                l.lesson_title,
                l.lesson_content
            FROM lessons l
            JOIN courses c ON l.course_id = c.course_id
            ORDER BY l.course_id ASC, l.lesson_number ASC
        `;
        const result = await db.query(query);
        res.json(result.rows);
    } catch (err) {
        console.error('Error fetching lessons:', err);
        res.status(500).json({ error: 'Failed to fetch lessons', details: err.message });
    }
});

// GET /api/lessons/:id - Get single lesson
router.get('/:id', async (req, res) => {
    try {
        const { id } = req.params;
        const query = `
            SELECT 
                l.lesson_id,
                l.course_id,
                c.course_name,
                l.lesson_number,
                l.lesson_title,
                l.lesson_content
            FROM lessons l
            JOIN courses c ON l.course_id = c.course_id
            WHERE l.lesson_id = $1
        `;
        const result = await db.query(query, [id]);
        if (result.rows.length === 0) {
            return res.status(404).json({ error: 'Lesson not found' });
        }
        res.json(result.rows[0]);
    } catch (err) {
        console.error('Error fetching lesson:', err);
        res.status(500).json({ error: 'Failed to fetch lesson', details: err.message });
    }
});

// POST /api/lessons - Add lesson
router.post('/', async (req, res) => {
    try {
        const { course_id, lesson_number, lesson_title, lesson_content } = req.body;
        if (!course_id || !lesson_number || !lesson_title) {
            return res.status(400).json({ error: 'Course, lesson number, and lesson title are required.' });
        }
        const query = `
            INSERT INTO lessons (course_id, lesson_number, lesson_title, lesson_content)
            VALUES ($1, $2, $3, $4)
            RETURNING *
        `;
        const result = await db.query(query, [parseInt(course_id, 10), parseInt(lesson_number, 10), lesson_title, lesson_content || null]);
        res.status(201).json(result.rows[0]);
    } catch (err) {
        console.error('Error adding lesson:', err);
        if (err.code === '23503') {
            return res.status(400).json({ error: 'Selected course does not exist.' });
        }
        res.status(500).json({ error: 'Failed to add lesson', details: err.message });
    }
});

// PUT /api/lessons/:id - Update lesson
router.put('/:id', async (req, res) => {
    try {
        const { id } = req.params;
        const { course_id, lesson_number, lesson_title, lesson_content } = req.body;
        if (!course_id || !lesson_number || !lesson_title) {
            return res.status(400).json({ error: 'Course, lesson number, and lesson title are required.' });
        }
        const query = `
            UPDATE lessons
            SET course_id = $1, lesson_number = $2, lesson_title = $3, lesson_content = $4
            WHERE lesson_id = $5
            RETURNING *
        `;
        const result = await db.query(query, [parseInt(course_id, 10), parseInt(lesson_number, 10), lesson_title, lesson_content || null, id]);
        if (result.rows.length === 0) {
            return res.status(404).json({ error: 'Lesson not found' });
        }
        res.json(result.rows[0]);
    } catch (err) {
        console.error('Error updating lesson:', err);
        if (err.code === '23503') {
            return res.status(400).json({ error: 'Selected course does not exist.' });
        }
        res.status(500).json({ error: 'Failed to update lesson', details: err.message });
    }
});

// DELETE /api/lessons/:id - Delete lesson
router.delete('/:id', async (req, res) => {
    try {
        const { id } = req.params;
        const result = await db.query('DELETE FROM lessons WHERE lesson_id = $1 RETURNING *', [id]);
        if (result.rows.length === 0) {
            return res.status(404).json({ error: 'Lesson not found' });
        }
        res.json({ message: 'Lesson deleted successfully', deleted: result.rows[0] });
    } catch (err) {
        console.error('Error deleting lesson:', err);
        res.status(500).json({ error: 'Failed to delete lesson', details: err.message });
    }
});

module.exports = router;
