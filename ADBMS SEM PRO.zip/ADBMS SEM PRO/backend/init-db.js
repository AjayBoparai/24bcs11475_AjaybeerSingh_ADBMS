const fs = require('fs');
const path = require('path');
const db = require('./db');

async function initializeDatabase() {
    console.log('🔄 Initializing PostgreSQL database (elearning_db)...');
    try {
        const schemaPath = path.join(__dirname, '..', 'database', 'schema.sql');
        const sampleDataPath = path.join(__dirname, '..', 'database', 'sample_data.sql');

        const schemaSql = fs.readFileSync(schemaPath, 'utf8');
        const sampleDataSql = fs.readFileSync(sampleDataPath, 'utf8');

        console.log('📦 Executing schema.sql...');
        await db.query(schemaSql);
        console.log('✅ Schema created successfully!');

        console.log('🌱 Executing sample_data.sql...');
        await db.query(sampleDataSql);
        console.log('✅ Sample data populated successfully!');

        const stats = await db.query(`
            SELECT 
                (SELECT COUNT(*) FROM students) AS students,
                (SELECT COUNT(*) FROM instructors) AS instructors,
                (SELECT COUNT(*) FROM courses) AS courses,
                (SELECT COUNT(*) FROM lessons) AS lessons,
                (SELECT COUNT(*) FROM enrollments) AS enrollments,
                (SELECT COUNT(*) FROM assignments) AS assignments,
                (SELECT COUNT(*) FROM submissions) AS submissions
        `);
        console.log('📊 Current Database Record Counts:');
        console.table(stats.rows[0]);

        console.log('🎉 Database initialization complete!');
        process.exit(0);
    } catch (err) {
        console.error('❌ Database initialization error:', err.message);
        process.exit(1);
    }
}

initializeDatabase();
