# E-Learning Management System — ADBMS Database Project

A clean, relational database project for an Advanced Database Management Systems (ADBMS) college course, demonstrating relational schema design, 3NF normalization, integrity constraints, SQL queries, stored functions, triggers, database views, and a minimal web interface.

---

## 1. Project Overview & Objective

This project focuses primarily on **Database Design & ADBMS Concepts** rather than complex application logic. It demonstrates how to model, enforce integrity, normalize, and query an educational domain with seven core relational entities:

- **Students**: Enrolled learners with contact and academic details.
- **Instructors**: Academic faculty members teaching courses.
- **Courses**: Subjects offered across various academic categories.
- **Lessons**: Sequential curriculum units under each course.
- **Enrollments**: Student course registrations resolving Many-to-Many ($N:M$) relationships with progress tracking.
- **Assignments**: Coursework with deadlines and maximum marks.
- **Submissions**: Student assignment submissions with awarded marks.

---

## 2. Technology Stack

- **Database**: PostgreSQL 16+
- **Backend**: Node.js & Express (`pg` driver)
- **Frontend**: Plain HTML5, CSS3, and JavaScript (Vanilla JS, no heavy frontend frameworks)

---

## 3. Entity-Relationship (ER) Architecture

```
                    +---------------+
                    |  INSTRUCTORS  |
                    +---------------+
                            | 1
                            |
                            | N
                    +---------------+
                    |    COURSES    |
                    +---------------+
                     /      |      \
                  1 /     1 |       \ 1
                   /        |        \
                  v N       v N       v N
             +---------+ +-------------+ +-------------+
             | LESSONS | | ENROLLMENTS | | ASSIGNMENTS |
             +---------+ +-------------+ +-------------+
                                | N             | 1
                                |               |
                                | 1             | N
                         +----------+    +-------------+
                         | STUDENTS |<---| SUBMISSIONS |
                         +----------+  N +-------------+
```

### Mermaid Diagram

```mermaid
erDiagram
    INSTRUCTORS ||--o{ COURSES : "teaches (1:N)"
    COURSES ||--o{ LESSONS : "contains (1:N)"
    COURSES ||--o{ ASSIGNMENTS : "assigns (1:N)"
    STUDENTS ||--o{ ENROLLMENTS : "registers (1:N)"
    COURSES ||--o{ ENROLLMENTS : "has (1:N)"
    STUDENTS ||--o{ SUBMISSIONS : "submits (1:N)"
    ASSIGNMENTS ||--o{ SUBMISSIONS : "receives (1:N)"

    STUDENTS {
        int student_id PK
        string name
        string email UK
        string phone
        string department
        int semester
    }
    INSTRUCTORS {
        int instructor_id PK
        string name
        string email UK
        string department
    }
    COURSES {
        int course_id PK
        string course_name
        string description
        string category
        int instructor_id FK
    }
    LESSONS {
        int lesson_id PK
        int course_id FK
        int lesson_number
        string lesson_title
        string lesson_content
    }
    ENROLLMENTS {
        int enrollment_id PK
        int student_id FK
        int course_id FK
        date enrollment_date
        int progress
    }
    ASSIGNMENTS {
        int assignment_id PK
        int course_id FK
        string title
        string description
        date due_date
        int max_marks
    }
    SUBMISSIONS {
        int submission_id PK
        int assignment_id FK
        int student_id FK
        date submission_date
        int marks
    }
```

---

## 4. Tables and Schema Description

| Table Name | Primary Key | Foreign Keys | Key Constraints | Description |
|---|---|---|---|---|
| `students` | `student_id` | *None* | `email UNIQUE`, `semester CHECK (1-8)` | Stores student demographic & academic year data |
| `instructors` | `instructor_id` | *None* | `email UNIQUE` | Stores faculty information |
| `courses` | `course_id` | `instructor_id -> instructors(instructor_id)` | `ON UPDATE CASCADE`, `ON DELETE RESTRICT` | Catalogs offered courses |
| `lessons` | `lesson_id` | `course_id -> courses(course_id)` | `lesson_number CHECK (> 0)`, `ON DELETE CASCADE` | Sequential lessons for each course |
| `enrollments` | `enrollment_id` | `student_id -> students`, `course_id -> courses` | `UNIQUE(student_id, course_id)`, `progress CHECK (0-100)` | Resolves student-course M:N relationship |
| `assignments` | `assignment_id` | `course_id -> courses(course_id)` | `max_marks CHECK (> 0)`, `ON DELETE CASCADE` | Course assignments with scoring criteria |
| `submissions` | `submission_id` | `assignment_id -> assignments`, `student_id -> students` | `marks CHECK (>= 0)`, `UNIQUE(student_id, assignment_id)` | Student assignment submissions & marks |

---

## 5. Relational Integrity & Constraints

1. **Primary Key Constraints**: Enforced on each table with auto-incrementing `SERIAL` surrogate keys.
2. **Foreign Key Constraints with Cascade Rules**:
   - `courses.instructor_id -> instructors(instructor_id)` with `ON DELETE RESTRICT` to prevent accidental deletion of faculty with assigned courses.
   - Deleting a course cascades (`ON DELETE CASCADE`) to its associated `lessons`, `enrollments`, and `assignments`.
3. **Candidate / Unique Keys**:
   - `students.email` and `instructors.email` prevent duplicate user registration.
   - Composite unique `(student_id, course_id)` ensures a student cannot enroll in the same course more than once.
   - Composite unique `(student_id, assignment_id)` ensures only one submission record per student per assignment.
4. **Domain Integrity (CHECK Constraints)**:
   - `enrollments.progress BETWEEN 0 AND 100`
   - `submissions.marks >= 0`
   - `assignments.max_marks > 0`
   - `students.semester BETWEEN 1 AND 8`

---

## 6. Normalization Analysis (3NF)

The database schema is verified in **Third Normal Form (3NF)**:

### 1. First Normal Form (1NF)
- **Criterion**: All column attributes contain atomic (indivisible) values, and there are no repeating groups or multi-valued columns.
- **Verification**: Attributes such as `phone`, `email`, `department`, and `progress` contain singular atomic data. All records have a distinct primary key.

### 2. Second Normal Form (2NF)
- **Criterion**: The table must be in 1NF and all non-key attributes must be fully functionally dependent on the entire primary key (no partial functional dependency).
- **Verification**: In all tables, the primary key is a single attribute (`student_id`, `course_id`, `enrollment_id`, etc.). Because no table relies on a composite primary key to identify its non-key attributes, **partial dependency cannot exist**. In the bridge table `enrollments`, attributes like `progress` and `enrollment_date` depend on the specific enrollment instance (`enrollment_id`), not partially on student or course alone.

### 3. Third Normal Form (3NF)
- **Criterion**: The table must be in 2NF and have no transitive functional dependencies (non-key attributes depending on other non-key attributes: $X \to Y$ and $Y \to Z$).
- **Verification**:
  - In `courses`, the table only references `instructor_id`. We do **not** store the instructor's name, email, or department inside `courses`.
  - In `enrollments`, we do not duplicate student names or course titles; only the foreign keys `student_id` and `course_id` are stored.
  - In `submissions`, marks depend directly on the submission; assignment details reside exclusively in `assignments`.
  - Thus, all non-key attributes depend **only** on the primary key, satisfying 3NF.

---

## 7. Advanced ADBMS Features Implemented

### 1. Database VIEW: `course_enrollment_details`
Combines relational data from 4 tables (`courses`, `instructors`, `students`, and `enrollments`) into a clean virtual table:
```sql
CREATE OR REPLACE VIEW course_enrollment_details AS
SELECT 
    c.course_name,
    i.name AS instructor,
    s.name AS student,
    e.enrollment_date,
    e.progress
FROM enrollments e
JOIN courses c ON e.course_id = c.course_id
JOIN instructors i ON c.instructor_id = i.instructor_id
JOIN students s ON e.student_id = s.student_id;
```

### 2. PL/pgSQL Stored Function: `get_course_enrollment_count(course_id)`
Encapsulates logic to count active enrollments for any course:
```sql
CREATE OR REPLACE FUNCTION get_course_enrollment_count(p_course_id INT)
RETURNS INT AS $$
DECLARE
    v_count INT;
BEGIN
    SELECT COUNT(*) INTO v_count
    FROM enrollments
    WHERE course_id = p_course_id;
    RETURN v_count;
END;
$$ LANGUAGE plpgsql;
```

### 3. Database Trigger: `trg_check_enrollment_progress`
Enforces business rules at the database engine level, rejecting invalid progress values before `INSERT` or `UPDATE`:
```sql
CREATE OR REPLACE FUNCTION check_enrollment_progress()
RETURNS TRIGGER AS $$
BEGIN
    IF NEW.progress < 0 OR NEW.progress > 100 THEN
        RAISE EXCEPTION 'Invalid progress value: %. Progress must be between 0 and 100.', NEW.progress;
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_check_enrollment_progress
BEFORE INSERT OR UPDATE ON enrollments
FOR EACH ROW
EXECUTE FUNCTION check_enrollment_progress();
```

### 4. Database Indexes
Optimizes foreign key lookups and search speeds:
```sql
CREATE INDEX idx_students_email ON students(email);
CREATE INDEX idx_courses_instructor_id ON courses(instructor_id);
CREATE INDEX idx_enrollments_student_id ON enrollments(student_id);
CREATE INDEX idx_enrollments_course_id ON enrollments(course_id);
CREATE INDEX idx_lessons_course_id ON lessons(course_id);
CREATE INDEX idx_assignments_course_id ON assignments(course_id);
CREATE INDEX idx_submissions_assignment_id ON submissions(assignment_id);
CREATE INDEX idx_submissions_student_id ON submissions(student_id);
```

---

## 8. Demonstrated SQL Concepts (`database/queries.sql`)

The repository includes 15 commented queries demonstrating:
- **Basic Projection & Filtering**: `SELECT ... WHERE ... ORDER BY`
- **Data Modification**: `INSERT ... RETURNING`, `UPDATE`, `DELETE`
- **INNER JOIN**: 1:N and Multi-Table joins across 4 entities
- **LEFT OUTER JOIN**: Identifying un-enrolled students with `IS NULL` anti-joins
- **Aggregation**: `COUNT()`, `SUM()`, `AVG()`, `MIN()`, `MAX()`
- **Grouping & Group Filtering**: `GROUP BY` and `HAVING`
- **Nested Subqueries**: Comparing against calculated scalar aggregates
- **VIEW Querying**: Querying virtual views
- **Stored Function Execution**: Calling custom PL/pgSQL functions

---

## 9. Project Directory Structure

```text
ADBMS SEM PRO/
├── database/
│   ├── schema.sql          # Core tables, constraints, indexes, view, function, trigger
│   ├── sample_data.sql     # 10 Students, 5 Instructors, 8 Courses, 24 Lessons, etc.
│   └── queries.sql         # 15 ADBMS demonstration SQL queries
│
├── backend/
│   ├── server.js           # Express application entry point & static server
│   ├── db.js               # PostgreSQL connection pool (pg.Pool)
│   ├── init-db.js          # Automated database schema & seed runner
│   └── routes/             # RESTful API endpoints for each entity
│       ├── stats.js        # Summary counts via COUNT() queries
│       ├── students.js     # Student CRUD
│       ├── instructors.js  # Instructor CRUD
│       ├── courses.js      # Course CRUD with instructor JOIN
│       ├── lessons.js      # Lesson CRUD with course JOIN
│       ├── enrollments.js  # Enrollment CRUD with student/course JOIN
│       ├── assignments.js  # Assignment CRUD with course JOIN
│       ├── submissions.js  # Submission CRUD with student/assignment JOIN
│       └── queries.js      # Live SQL query runner & view endpoint
│
├── frontend/
│   ├── index.html          # Minimal user interface
│   ├── style.css           # Clean, responsive light theme styling
│   └── script.js           # Fetch API logic, dynamic tables, modals, query runner
│
├── .env                    # Database connection credentials
├── .env.example            # Environment template
├── docker-compose.yml      # Optional PostgreSQL Docker setup (port 5433:5432)
├── package.json            # Node.js project manifest & dependencies
└── README.md               # Project documentation
```

---

## 10. How to Run the Project

### Prerequisites
- Node.js (v18+)
- PostgreSQL (Local or via Docker)

### Option A: Running with Local PostgreSQL

1. **Verify your `.env` configuration**:
   ```ini
   DB_HOST=127.0.0.1
   DB_PORT=5433         # Or 5432 depending on your PostgreSQL service port
   DB_USER=postgres
   DB_PASSWORD=postgres
   DB_NAME=elearning_db
   PORT=3000
   ```

2. **Install dependencies**:
   ```bash
   npm install
   ```

3. **Initialize the database** (Runs schema and seeds sample data):
   ```bash
   npm run init-db
   ```

4. **Start the application**:
   ```bash
   npm start
   ```

5. **Open in browser**:
   Visit [http://localhost:3000](http://localhost:3000)

---

### Option B: Running PostgreSQL via Docker (Port 5433)

If you prefer using Docker for PostgreSQL without interfering with any existing local PostgreSQL installation:

1. **Start the database container**:
   ```bash
   docker compose up -d
   ```
   *Note: This starts `postgres:16` exposing host port `5433:5432` and automatically mounts and initializes `database/schema.sql` and `database/sample_data.sql`.*

2. **Start the Node.js application**:
   ```bash
   npm start
   ```

3. **Visit**: [http://localhost:3000](http://localhost:3000)

---

## 11. Viva Voce Highlights & Quick Answers

- **Why is `enrollments` a separate table?**
  A student can enroll in multiple courses, and a course has multiple students. To resolve this Many-to-Many ($M:N$) relationship into two $1:N$ relationships, we introduce the associative/bridge table `enrollments`.
- **How is data integrity maintained if an instructor is deleted?**
  `courses.instructor_id` specifies `ON DELETE RESTRICT`, preventing accidental orphan courses if a faculty record is deleted.
- **How does the trigger differ from a CHECK constraint?**
  While `CHECK` handles simple static expressions, PL/pgSQL triggers can run custom procedural logic, perform cross-table validations, raise detailed custom error messages, and maintain audit logs.
- **Why are indexes placed on Foreign Keys?**
  PostgreSQL automatically indexes Primary Keys, but does not automatically index Foreign Keys. Creating indexes on `courses(instructor_id)` and `enrollments(course_id, student_id)` speeds up relational `JOIN` operations.
