/**
 * E-Learning Management System - ADBMS Frontend Controller
 * Connects directly to Express REST API backed by PostgreSQL.
 */

// API Base URL
const API_BASE = '/api';

// Current active state
let currentTab = 'students';
let cachedData = {};
let availableQueries = [];
let pendingDelete = null;

// DOM Elements
const statStudents = document.getElementById('statStudents');
const statInstructors = document.getElementById('statInstructors');
const statCourses = document.getElementById('statCourses');
const statEnrollments = document.getElementById('statEnrollments');
const statLessons = document.getElementById('statLessons');
const statAssignments = document.getElementById('statAssignments');
const statSubmissions = document.getElementById('statSubmissions');

const navButtons = document.querySelectorAll('.nav-btn');
const sectionTitle = document.getElementById('sectionTitle');
const sectionDesc = document.getElementById('sectionDesc');
const refreshBtn = document.getElementById('refreshBtn');
const addNewBtn = document.getElementById('addNewBtn');

const mainDataTable = document.getElementById('mainDataTable');
const tableHead = document.getElementById('tableHead');
const tableBody = document.getElementById('tableBody');
const queriesContainer = document.getElementById('queriesContainer');

// Modal Elements
const modalOverlay = document.getElementById('modalOverlay');
const modalTitle = document.getElementById('modalTitle');
const genericForm = document.getElementById('genericForm');
const formFieldsContainer = document.getElementById('formFieldsContainer');
const modalError = document.getElementById('modalError');
const editRecordId = document.getElementById('editRecordId');
const modalCloseBtn = document.getElementById('modalCloseBtn');
const modalCancelBtn = document.getElementById('modalCancelBtn');

// Delete Modal Elements
const deleteOverlay = document.getElementById('deleteOverlay');
const deleteMessage = document.getElementById('deleteMessage');
const deleteError = document.getElementById('deleteError');
const deleteConfirmBtn = document.getElementById('deleteConfirmBtn');
const deleteCancelBtn = document.getElementById('deleteCancelBtn');
const deleteCloseBtn = document.getElementById('deleteCloseBtn');

// Toast
const toastNotification = document.getElementById('toastNotification');

// Query Runner Elements
const querySelect = document.getElementById('querySelect');
const runQueryBtn = document.getElementById('runQueryBtn');
const queryConceptBadge = document.getElementById('queryConceptBadge');
const queryTitleDisplay = document.getElementById('queryTitleDisplay');
const querySqlDisplay = document.getElementById('querySqlDisplay');
const queryResultCount = document.getElementById('queryResultCount');
const queryResultHead = document.getElementById('queryResultHead');
const queryResultBody = document.getElementById('queryResultBody');

// ============================================================================
// INITIALIZATION
// ============================================================================
document.addEventListener('DOMContentLoaded', () => {
    setupNavigation();
    setupEventHandlers();
    loadStats();
    loadTabData(currentTab);
});

// Toast notification helper
function showToast(message, type = 'success') {
    toastNotification.textContent = message;
    toastNotification.className = `toast ${type}`;
    setTimeout(() => {
        toastNotification.className = 'toast hidden';
    }, 4500);
}

// Fetch aggregate statistics from PostgreSQL (COUNT queries)
async function loadStats() {
    try {
        const res = await fetch(`${API_BASE}/stats`);
        if (!res.ok) throw new Error('Failed to fetch statistics');
        const stats = await res.json();
        
        statStudents.textContent = stats.students ?? 0;
        statInstructors.textContent = stats.instructors ?? 0;
        statCourses.textContent = stats.courses ?? 0;
        statEnrollments.textContent = stats.enrollments ?? 0;
        statLessons.textContent = stats.lessons ?? 0;
        statAssignments.textContent = stats.assignments ?? 0;
        statSubmissions.textContent = stats.submissions ?? 0;
    } catch (err) {
        console.error('Error loading stats:', err);
    }
}

// Setup tab navigation
function setupNavigation() {
    navButtons.forEach(btn => {
        btn.addEventListener('click', () => {
            const tab = btn.dataset.tab;
            if (tab === currentTab) return;

            navButtons.forEach(b => b.classList.remove('active'));
            btn.classList.add('active');

            currentTab = tab;
            loadTabData(tab);
        });
    });
}

// Setup Event Listeners
function setupEventHandlers() {
    refreshBtn.addEventListener('click', () => {
        loadStats();
        loadTabData(currentTab);
    });

    addNewBtn.addEventListener('click', () => {
        openAddModal(currentTab);
    });

    modalCloseBtn.addEventListener('click', closeModal);
    modalCancelBtn.addEventListener('click', closeModal);
    deleteCloseBtn.addEventListener('click', closeDeleteModal);
    deleteCancelBtn.addEventListener('click', closeDeleteModal);

    genericForm.addEventListener('submit', handleFormSubmit);
    deleteConfirmBtn.addEventListener('click', handleConfirmDelete);

    runQueryBtn.addEventListener('click', executeSelectedQuery);
    querySelect.addEventListener('change', updateQueryDisplay);
}

// ============================================================================
// DATA LOADING AND RENDERING
// ============================================================================
async function loadTabData(tab) {
    // Reset view visibility
    if (tab === 'queries') {
        mainDataTable.parentElement.classList.add('hidden');
        queriesContainer.classList.remove('hidden');
        addNewBtn.classList.add('hidden');
        sectionTitle.textContent = 'SQL Queries Demonstration';
        sectionDesc.textContent = 'Execute useful ADBMS queries live against PostgreSQL (JOINs, Aggregates, Subqueries, Stored Functions).';
        loadDemoQueries();
        return;
    }

    mainDataTable.parentElement.classList.remove('hidden');
    queriesContainer.classList.add('hidden');

    if (tab === 'view') {
        addNewBtn.classList.add('hidden');
        sectionTitle.textContent = 'ADBMS View: course_enrollment_details';
        sectionDesc.textContent = 'Demonstrating PostgreSQL VIEW combining Course, Instructor, Student, and Progress information.';
    } else {
        addNewBtn.classList.remove('hidden');
        addNewBtn.textContent = `+ Add ${getSingularTitle(tab)}`;
        sectionTitle.textContent = `${tab.charAt(0).toUpperCase() + tab.slice(1)} Table`;
        sectionDesc.textContent = getTableDescription(tab);
    }

    tableBody.innerHTML = `<tr><td colspan="8" class="loading-state">Loading data from PostgreSQL...</td></tr>`;

    try {
        let endpoint = `${API_BASE}/${tab}`;
        if (tab === 'view') {
            endpoint = `${API_BASE}/queries/view/course-enrollments`;
        }

        const res = await fetch(endpoint);
        if (!res.ok) throw new Error(`HTTP error ${res.status}`);
        const data = await res.json();
        cachedData[tab] = data;

        renderTable(tab, data);
    } catch (err) {
        console.error(`Error loading ${tab}:`, err);
        tableBody.innerHTML = `<tr><td colspan="8" class="loading-state" style="color: #dc2626;">Failed to load data from database: ${err.message}</td></tr>`;
    }
}

function getSingularTitle(tab) {
    const titles = {
        students: 'Student',
        instructors: 'Instructor',
        courses: 'Course',
        lessons: 'Lesson',
        enrollments: 'Enrollment',
        assignments: 'Assignment',
        submissions: 'Submission'
    };
    return titles[tab] || 'Record';
}

function getTableDescription(tab) {
    const desc = {
        students: 'Manage student records with PRIMARY KEY, UNIQUE email, and semester CHECK constraints.',
        instructors: 'Manage instructor profiles with PRIMARY KEY and UNIQUE email constraints.',
        courses: 'Demonstrates 1:N relationship with Instructors via FOREIGN KEY (instructor_id).',
        lessons: 'Demonstrates 1:N relationship with Courses via FOREIGN KEY (course_id).',
        enrollments: 'Resolves Student N:M Course relationship with UNIQUE(student_id, course_id) and progress CHECK.',
        assignments: 'Demonstrates 1:N relationship with Courses with max_marks CHECK constraint.',
        submissions: 'Demonstrates N:1 relationships with Assignments and Students with marks CHECK constraint.'
    };
    return desc[tab] || '';
}

// Render dynamic tables based on table metadata
function renderTable(tab, data) {
    if (!data || data.length === 0) {
        tableHead.innerHTML = '';
        tableBody.innerHTML = `<tr><td colspan="8" class="loading-state">No records found in PostgreSQL table.</td></tr>`;
        return;
    }

    let headersHtml = '';
    let rowsHtml = '';

    switch (tab) {
        case 'students':
            headersHtml = `
                <tr>
                    <th>Student ID</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Phone</th>
                    <th>Department</th>
                    <th>Semester</th>
                    <th>Actions</th>
                </tr>
            `;
            rowsHtml = data.map(s => `
                <tr>
                    <td><strong>${s.student_id}</strong></td>
                    <td>${escapeHtml(s.name)}</td>
                    <td>${escapeHtml(s.email)}</td>
                    <td>${escapeHtml(s.phone || '-')}</td>
                    <td>${escapeHtml(s.department)}</td>
                    <td>Semester ${s.semester}</td>
                    <td class="actions-cell">
                        <button class="btn btn-secondary btn-sm" onclick="openEditModal('students', ${s.student_id})">Edit</button>
                        <button class="btn btn-danger btn-sm" onclick="openDeleteModal('students', ${s.student_id}, '${escapeHtml(s.name)}')">Delete</button>
                    </td>
                </tr>
            `).join('');
            break;

        case 'instructors':
            headersHtml = `
                <tr>
                    <th>Instructor ID</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Department</th>
                    <th>Actions</th>
                </tr>
            `;
            rowsHtml = data.map(i => `
                <tr>
                    <td><strong>${i.instructor_id}</strong></td>
                    <td>${escapeHtml(i.name)}</td>
                    <td>${escapeHtml(i.email)}</td>
                    <td>${escapeHtml(i.department)}</td>
                    <td class="actions-cell">
                        <button class="btn btn-secondary btn-sm" onclick="openEditModal('instructors', ${i.instructor_id})">Edit</button>
                        <button class="btn btn-danger btn-sm" onclick="openDeleteModal('instructors', ${i.instructor_id}, '${escapeHtml(i.name)}')">Delete</button>
                    </td>
                </tr>
            `).join('');
            break;

        case 'courses':
            headersHtml = `
                <tr>
                    <th>Course ID</th>
                    <th>Course Name</th>
                    <th>Category</th>
                    <th>Instructor (JOIN)</th>
                    <th>Description</th>
                    <th>Actions</th>
                </tr>
            `;
            rowsHtml = data.map(c => `
                <tr>
                    <td><strong>${c.course_id}</strong></td>
                    <td><strong>${escapeHtml(c.course_name)}</strong></td>
                    <td><span class="badge">${escapeHtml(c.category)}</span></td>
                    <td>${escapeHtml(c.instructor_name || 'ID: ' + c.instructor_id)}</td>
                    <td><small style="color: #64748b;">${escapeHtml(c.description || '-')}</small></td>
                    <td class="actions-cell">
                        <button class="btn btn-secondary btn-sm" onclick="openEditModal('courses', ${c.course_id})">Edit</button>
                        <button class="btn btn-danger btn-sm" onclick="openDeleteModal('courses', ${c.course_id}, '${escapeHtml(c.course_name)}')">Delete</button>
                    </td>
                </tr>
            `).join('');
            break;

        case 'lessons':
            headersHtml = `
                <tr>
                    <th>Lesson ID</th>
                    <th>Course Name (JOIN)</th>
                    <th>Lesson #</th>
                    <th>Lesson Title</th>
                    <th>Lesson Content</th>
                    <th>Actions</th>
                </tr>
            `;
            rowsHtml = data.map(l => `
                <tr>
                    <td><strong>${l.lesson_id}</strong></td>
                    <td>${escapeHtml(l.course_name || 'Course ' + l.course_id)}</td>
                    <td>${l.lesson_number}</td>
                    <td><strong>${escapeHtml(l.lesson_title)}</strong></td>
                    <td><small style="color: #64748b;">${escapeHtml(l.lesson_content || '-')}</small></td>
                    <td class="actions-cell">
                        <button class="btn btn-secondary btn-sm" onclick="openEditModal('lessons', ${l.lesson_id})">Edit</button>
                        <button class="btn btn-danger btn-sm" onclick="openDeleteModal('lessons', ${l.lesson_id}, '${escapeHtml(l.lesson_title)}')">Delete</button>
                    </td>
                </tr>
            `).join('');
            break;

        case 'enrollments':
            headersHtml = `
                <tr>
                    <th>Enrollment ID</th>
                    <th>Student (JOIN)</th>
                    <th>Course (JOIN)</th>
                    <th>Enrollment Date</th>
                    <th>Progress</th>
                    <th>Actions</th>
                </tr>
            `;
            rowsHtml = data.map(e => `
                <tr>
                    <td><strong>${e.enrollment_id}</strong></td>
                    <td>${escapeHtml(e.student_name || 'Student ' + e.student_id)}</td>
                    <td><strong>${escapeHtml(e.course_name || 'Course ' + e.course_id)}</strong></td>
                    <td>${e.enrollment_date}</td>
                    <td>
                        <div class="progress-container">
                            <div class="progress-bar-bg">
                                <div class="progress-bar-fill" style="width: ${e.progress}%"></div>
                            </div>
                            <span class="progress-text">${e.progress}%</span>
                        </div>
                    </td>
                    <td class="actions-cell">
                        <button class="btn btn-secondary btn-sm" onclick="openEditModal('enrollments', ${e.enrollment_id})">Edit</button>
                        <button class="btn btn-danger btn-sm" onclick="openDeleteModal('enrollments', ${e.enrollment_id}, 'Enrollment #${e.enrollment_id}')">Delete</button>
                    </td>
                </tr>
            `).join('');
            break;

        case 'assignments':
            headersHtml = `
                <tr>
                    <th>Assignment ID</th>
                    <th>Course (JOIN)</th>
                    <th>Title</th>
                    <th>Due Date</th>
                    <th>Max Marks</th>
                    <th>Actions</th>
                </tr>
            `;
            rowsHtml = data.map(a => `
                <tr>
                    <td><strong>${a.assignment_id}</strong></td>
                    <td>${escapeHtml(a.course_name || 'Course ' + a.course_id)}</td>
                    <td><strong>${escapeHtml(a.title)}</strong></td>
                    <td>${a.due_date}</td>
                    <td>${a.max_marks} pts</td>
                    <td class="actions-cell">
                        <button class="btn btn-secondary btn-sm" onclick="openEditModal('assignments', ${a.assignment_id})">Edit</button>
                        <button class="btn btn-danger btn-sm" onclick="openDeleteModal('assignments', ${a.assignment_id}, '${escapeHtml(a.title)}')">Delete</button>
                    </td>
                </tr>
            `).join('');
            break;

        case 'submissions':
            headersHtml = `
                <tr>
                    <th>Submission ID</th>
                    <th>Student (JOIN)</th>
                    <th>Assignment (JOIN)</th>
                    <th>Course</th>
                    <th>Submission Date</th>
                    <th>Marks Obtained</th>
                    <th>Actions</th>
                </tr>
            `;
            rowsHtml = data.map(sub => `
                <tr>
                    <td><strong>${sub.submission_id}</strong></td>
                    <td>${escapeHtml(sub.student_name || 'Student ' + sub.student_id)}</td>
                    <td><strong>${escapeHtml(sub.assignment_title || 'Assignment ' + sub.assignment_id)}</strong></td>
                    <td>${escapeHtml(sub.course_name || '-')}</td>
                    <td>${sub.submission_date}</td>
                    <td><strong>${sub.marks !== null ? sub.marks : '-'}</strong> / ${sub.max_marks || '-'}</td>
                    <td class="actions-cell">
                        <button class="btn btn-secondary btn-sm" onclick="openEditModal('submissions', ${sub.submission_id})">Edit</button>
                        <button class="btn btn-danger btn-sm" onclick="openDeleteModal('submissions', ${sub.submission_id}, 'Submission #${sub.submission_id}')">Delete</button>
                    </td>
                </tr>
            `).join('');
            break;

        case 'view':
            headersHtml = `
                <tr>
                    <th>Course Name</th>
                    <th>Instructor</th>
                    <th>Student</th>
                    <th>Enrollment Date</th>
                    <th>Progress</th>
                </tr>
            `;
            rowsHtml = data.map(v => `
                <tr>
                    <td><strong>${escapeHtml(v.course_name)}</strong></td>
                    <td>${escapeHtml(v.instructor)}</td>
                    <td>${escapeHtml(v.student)}</td>
                    <td>${v.enrollment_date}</td>
                    <td>
                        <div class="progress-container">
                            <div class="progress-bar-bg">
                                <div class="progress-bar-fill" style="width: ${v.progress}%"></div>
                            </div>
                            <span class="progress-text">${v.progress}%</span>
                        </div>
                    </td>
                </tr>
            `).join('');
            break;
    }

    tableHead.innerHTML = headersHtml;
    tableBody.innerHTML = rowsHtml;
}

// ============================================================================
// MODAL FORMS: ADD & EDIT
// ============================================================================
async function openAddModal(tab) {
    editRecordId.value = '';
    modalTitle.textContent = `Add New ${getSingularTitle(tab)}`;
    modalError.classList.add('hidden');
    formFieldsContainer.innerHTML = '<p class="loading-state">Preparing form...</p>';
    modalOverlay.classList.remove('hidden');

    try {
        await buildFormFields(tab, null);
    } catch (err) {
        modalError.textContent = `Error building form: ${err.message}`;
        modalError.classList.remove('hidden');
    }
}

async function openEditModal(tab, id) {
    editRecordId.value = id;
    modalTitle.textContent = `Edit ${getSingularTitle(tab)} (#${id})`;
    modalError.classList.add('hidden');
    formFieldsContainer.innerHTML = '<p class="loading-state">Loading record from database...</p>';
    modalOverlay.classList.remove('hidden');

    try {
        const res = await fetch(`${API_BASE}/${tab}/${id}`);
        if (!res.ok) throw new Error(`Could not fetch ${tab} #${id}`);
        const record = await res.json();
        await buildFormFields(tab, record);
    } catch (err) {
        modalError.textContent = `Error loading record: ${err.message}`;
        modalError.classList.remove('hidden');
    }
}

function closeModal() {
    modalOverlay.classList.add('hidden');
    genericForm.reset();
    editRecordId.value = '';
}

// Dynamic form builder tailored to each table and relationship
async function buildFormFields(tab, record) {
    let html = '';

    switch (tab) {
        case 'students':
            html = `
                <div class="form-group">
                    <label for="f_name">Full Name *</label>
                    <input type="text" id="f_name" name="name" class="form-input" required value="${record ? escapeHtml(record.name) : ''}">
                </div>
                <div class="form-group">
                    <label for="f_email">Email Address (UNIQUE) *</label>
                    <input type="email" id="f_email" name="email" class="form-input" required value="${record ? escapeHtml(record.email) : ''}">
                </div>
                <div class="form-group">
                    <label for="f_phone">Phone Number</label>
                    <input type="text" id="f_phone" name="phone" class="form-input" value="${record && record.phone ? escapeHtml(record.phone) : ''}">
                </div>
                <div class="form-group">
                    <label for="f_department">Department *</label>
                    <select id="f_department" name="department" class="form-input" required>
                        <option value="Computer Science" ${record && record.department === 'Computer Science' ? 'selected' : ''}>Computer Science</option>
                        <option value="Information Technology" ${record && record.department === 'Information Technology' ? 'selected' : ''}>Information Technology</option>
                        <option value="Electronics" ${record && record.department === 'Electronics' ? 'selected' : ''}>Electronics</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="f_semester">Semester (CHECK 1-8) *</label>
                    <input type="number" id="f_semester" name="semester" min="1" max="8" class="form-input" required value="${record ? record.semester : 1}">
                </div>
            `;
            break;

        case 'instructors':
            html = `
                <div class="form-group">
                    <label for="f_name">Instructor Name *</label>
                    <input type="text" id="f_name" name="name" class="form-input" required value="${record ? escapeHtml(record.name) : ''}">
                </div>
                <div class="form-group">
                    <label for="f_email">Email Address (UNIQUE) *</label>
                    <input type="email" id="f_email" name="email" class="form-input" required value="${record ? escapeHtml(record.email) : ''}">
                </div>
                <div class="form-group">
                    <label for="f_department">Department *</label>
                    <select id="f_department" name="department" class="form-input" required>
                        <option value="Computer Science" ${record && record.department === 'Computer Science' ? 'selected' : ''}>Computer Science</option>
                        <option value="Information Technology" ${record && record.department === 'Information Technology' ? 'selected' : ''}>Information Technology</option>
                        <option value="Electronics" ${record && record.department === 'Electronics' ? 'selected' : ''}>Electronics</option>
                    </select>
                </div>
            `;
            break;

        case 'courses': {
            const instructorsRes = await fetch(`${API_BASE}/instructors`);
            const instructors = await instructorsRes.json();
            const instructorOptions = instructors.map(i => `
                <option value="${i.instructor_id}" ${record && record.instructor_id == i.instructor_id ? 'selected' : ''}>
                    ${escapeHtml(i.name)} (${escapeHtml(i.department)})
                </option>
            `).join('');

            html = `
                <div class="form-group">
                    <label for="f_course_name">Course Name *</label>
                    <input type="text" id="f_course_name" name="course_name" class="form-input" required value="${record ? escapeHtml(record.course_name) : ''}">
                </div>
                <div class="form-group">
                    <label for="f_category">Category *</label>
                    <input type="text" id="f_category" name="category" class="form-input" required value="${record ? escapeHtml(record.category) : 'Core CS'}">
                </div>
                <div class="form-group">
                    <label for="f_instructor_id">Instructor (FOREIGN KEY) *</label>
                    <select id="f_instructor_id" name="instructor_id" class="form-input" required>
                        <option value="">-- Select Instructor --</option>
                        ${instructorOptions}
                    </select>
                </div>
                <div class="form-group">
                    <label for="f_description">Description</label>
                    <textarea id="f_description" name="description" class="form-input" rows="3">${record && record.description ? escapeHtml(record.description) : ''}</textarea>
                </div>
            `;
            break;
        }

        case 'lessons': {
            const coursesRes = await fetch(`${API_BASE}/courses`);
            const courses = await coursesRes.json();
            const courseOptions = courses.map(c => `
                <option value="${c.course_id}" ${record && record.course_id == c.course_id ? 'selected' : ''}>
                    ${escapeHtml(c.course_name)}
                </option>
            `).join('');

            html = `
                <div class="form-group">
                    <label for="f_course_id">Course (FOREIGN KEY) *</label>
                    <select id="f_course_id" name="course_id" class="form-input" required>
                        <option value="">-- Select Course --</option>
                        ${courseOptions}
                    </select>
                </div>
                <div class="form-group">
                    <label for="f_lesson_number">Lesson Number (CHECK > 0) *</label>
                    <input type="number" id="f_lesson_number" name="lesson_number" min="1" class="form-input" required value="${record ? record.lesson_number : 1}">
                </div>
                <div class="form-group">
                    <label for="f_lesson_title">Lesson Title *</label>
                    <input type="text" id="f_lesson_title" name="lesson_title" class="form-input" required value="${record ? escapeHtml(record.lesson_title) : ''}">
                </div>
                <div class="form-group">
                    <label for="f_lesson_content">Lesson Content</label>
                    <textarea id="f_lesson_content" name="lesson_content" class="form-input" rows="3">${record && record.lesson_content ? escapeHtml(record.lesson_content) : ''}</textarea>
                </div>
            `;
            break;
        }

        case 'enrollments': {
            const [studentsRes, coursesRes] = await Promise.all([
                fetch(`${API_BASE}/students`),
                fetch(`${API_BASE}/courses`)
            ]);
            const students = await studentsRes.json();
            const courses = await coursesRes.json();

            const studentOptions = students.map(s => `
                <option value="${s.student_id}" ${record && record.student_id == s.student_id ? 'selected' : ''}>
                    ${escapeHtml(s.name)} (${escapeHtml(s.department)})
                </option>
            `).join('');

            const courseOptions = courses.map(c => `
                <option value="${c.course_id}" ${record && record.course_id == c.course_id ? 'selected' : ''}>
                    ${escapeHtml(c.course_name)}
                </option>
            `).join('');

            const today = new Date().toISOString().split('T')[0];

            html = `
                <div class="form-group">
                    <label for="f_student_id">Student (FOREIGN KEY) *</label>
                    <select id="f_student_id" name="student_id" class="form-input" required>
                        <option value="">-- Select Student --</option>
                        ${studentOptions}
                    </select>
                </div>
                <div class="form-group">
                    <label for="f_course_id">Course (FOREIGN KEY) *</label>
                    <select id="f_course_id" name="course_id" class="form-input" required>
                        <option value="">-- Select Course --</option>
                        ${courseOptions}
                    </select>
                </div>
                <div class="form-group">
                    <label for="f_enrollment_date">Enrollment Date</label>
                    <input type="date" id="f_enrollment_date" name="enrollment_date" class="form-input" value="${record ? record.enrollment_date : today}">
                </div>
                <div class="form-group">
                    <label for="f_progress">Progress % (CHECK 0-100 & TRIGGER) *</label>
                    <input type="number" id="f_progress" name="progress" min="0" max="100" class="form-input" required value="${record ? record.progress : 0}">
                </div>
            `;
            break;
        }

        case 'assignments': {
            const coursesRes = await fetch(`${API_BASE}/courses`);
            const courses = await coursesRes.json();
            const courseOptions = courses.map(c => `
                <option value="${c.course_id}" ${record && record.course_id == c.course_id ? 'selected' : ''}>
                    ${escapeHtml(c.course_name)}
                </option>
            `).join('');

            const nextWeek = new Date();
            nextWeek.setDate(nextWeek.getDate() + 7);
            const defaultDueDate = nextWeek.toISOString().split('T')[0];

            html = `
                <div class="form-group">
                    <label for="f_course_id">Course (FOREIGN KEY) *</label>
                    <select id="f_course_id" name="course_id" class="form-input" required>
                        <option value="">-- Select Course --</option>
                        ${courseOptions}
                    </select>
                </div>
                <div class="form-group">
                    <label for="f_title">Assignment Title *</label>
                    <input type="text" id="f_title" name="title" class="form-input" required value="${record ? escapeHtml(record.title) : ''}">
                </div>
                <div class="form-group">
                    <label for="f_due_date">Due Date *</label>
                    <input type="date" id="f_due_date" name="due_date" class="form-input" required value="${record ? record.due_date : defaultDueDate}">
                </div>
                <div class="form-group">
                    <label for="f_max_marks">Maximum Marks (CHECK > 0) *</label>
                    <input type="number" id="f_max_marks" name="max_marks" min="1" class="form-input" required value="${record ? record.max_marks : 100}">
                </div>
                <div class="form-group">
                    <label for="f_description">Description</label>
                    <textarea id="f_description" name="description" class="form-input" rows="3">${record && record.description ? escapeHtml(record.description) : ''}</textarea>
                </div>
            `;
            break;
        }

        case 'submissions': {
            const [studentsRes, assignmentsRes] = await Promise.all([
                fetch(`${API_BASE}/students`),
                fetch(`${API_BASE}/assignments`)
            ]);
            const students = await studentsRes.json();
            const assignments = await assignmentsRes.json();

            const studentOptions = students.map(s => `
                <option value="${s.student_id}" ${record && record.student_id == s.student_id ? 'selected' : ''}>
                    ${escapeHtml(s.name)}
                </option>
            `).join('');

            const assignmentOptions = assignments.map(a => `
                <option value="${a.assignment_id}" ${record && record.assignment_id == a.assignment_id ? 'selected' : ''}>
                    ${escapeHtml(a.title)} (${escapeHtml(a.course_name)}) [Max: ${a.max_marks}]
                </option>
            `).join('');

            const today = new Date().toISOString().split('T')[0];

            html = `
                <div class="form-group">
                    <label for="f_assignment_id">Assignment (FOREIGN KEY) *</label>
                    <select id="f_assignment_id" name="assignment_id" class="form-input" required>
                        <option value="">-- Select Assignment --</option>
                        ${assignmentOptions}
                    </select>
                </div>
                <div class="form-group">
                    <label for="f_student_id">Student (FOREIGN KEY) *</label>
                    <select id="f_student_id" name="student_id" class="form-input" required>
                        <option value="">-- Select Student --</option>
                        ${studentOptions}
                    </select>
                </div>
                <div class="form-group">
                    <label for="f_submission_date">Submission Date</label>
                    <input type="date" id="f_submission_date" name="submission_date" class="form-input" value="${record ? record.submission_date : today}">
                </div>
                <div class="form-group">
                    <label for="f_marks">Marks Obtained (CHECK >= 0)</label>
                    <input type="number" id="f_marks" name="marks" min="0" class="form-input" value="${record && record.marks !== null ? record.marks : ''}">
                </div>
            `;
            break;
        }
    }

    formFieldsContainer.innerHTML = html;
}

// Handle Form Submission (POST / PUT)
async function handleFormSubmit(e) {
    e.preventDefault();
    modalError.classList.add('hidden');

    const formData = new FormData(genericForm);
    const payload = {};
    for (let [key, val] of formData.entries()) {
        payload[key] = val;
    }

    const id = editRecordId.value;
    const isEdit = Boolean(id);
    const method = isEdit ? 'PUT' : 'POST';
    const endpoint = isEdit ? `${API_BASE}/${currentTab}/${id}` : `${API_BASE}/${currentTab}`;

    try {
        const res = await fetch(endpoint, {
            method,
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        });

        const data = await res.json();
        if (!res.ok) {
            throw new Error(data.error || 'Operation failed');
        }

        closeModal();
        showToast(`${getSingularTitle(currentTab)} ${isEdit ? 'updated' : 'added'} successfully!`);
        loadStats();
        loadTabData(currentTab);
    } catch (err) {
        modalError.textContent = err.message;
        modalError.classList.remove('hidden');
    }
}

// ============================================================================
// DELETE OPERATIONS
// ============================================================================
function openDeleteModal(tab, id, label) {
    pendingDelete = { tab, id };
    deleteMessage.innerHTML = `Are you sure you want to delete <strong>${escapeHtml(label)}</strong> (ID #${id}) from the <code>${tab}</code> table?`;
    deleteError.classList.add('hidden');
    deleteOverlay.classList.remove('hidden');
}

function closeDeleteModal() {
    deleteOverlay.classList.add('hidden');
    pendingDelete = null;
}

async function handleConfirmDelete() {
    if (!pendingDelete) return;
    deleteError.classList.add('hidden');

    const { tab, id } = pendingDelete;
    try {
        const res = await fetch(`${API_BASE}/${tab}/${id}`, {
            method: 'DELETE'
        });

        const data = await res.json();
        if (!res.ok) {
            throw new Error(data.error || 'Failed to delete record');
        }

        closeDeleteModal();
        showToast(`Record #${id} deleted successfully.`);
        loadStats();
        loadTabData(currentTab);
    } catch (err) {
        deleteError.textContent = err.message;
        deleteError.classList.remove('hidden');
    }
}

// ============================================================================
// SQL QUERIES DEMONSTRATION RUNNER
// ============================================================================
async function loadDemoQueries() {
    try {
        const res = await fetch(`${API_BASE}/queries`);
        if (!res.ok) throw new Error('Could not fetch demonstration queries.');
        availableQueries = await res.json();

        querySelect.innerHTML = availableQueries.map(q => `
            <option value="${q.id}">Query ${q.id}: ${escapeHtml(q.title)}</option>
        `).join('');

        updateQueryDisplay();
    } catch (err) {
        console.error('Error loading queries:', err);
    }
}

function updateQueryDisplay() {
    const selectedId = parseInt(querySelect.value, 10);
    const queryItem = availableQueries.find(q => q.id === selectedId);
    if (!queryItem) return;

    queryConceptBadge.textContent = queryItem.concept;
    queryTitleDisplay.textContent = queryItem.title;
    querySqlDisplay.textContent = queryItem.sql;
}

async function executeSelectedQuery() {
    const selectedId = parseInt(querySelect.value, 10);
    queryResultHead.innerHTML = '';
    queryResultBody.innerHTML = `<tr><td class="loading-state">Executing query against PostgreSQL...</td></tr>`;
    queryResultCount.textContent = '';

    try {
        const res = await fetch(`${API_BASE}/queries/run/${selectedId}`);
        if (!res.ok) throw new Error('Query execution failed');
        const data = await res.json();

        queryResultCount.textContent = `(${data.rowCount} rows returned)`;

        if (!data.rows || data.rows.length === 0) {
            queryResultBody.innerHTML = `<tr><td class="loading-state">Query executed successfully, 0 rows returned.</td></tr>`;
            return;
        }

        // Generate headers dynamically from first result row keys
        const columns = Object.keys(data.rows[0]);
        queryResultHead.innerHTML = `<tr>${columns.map(c => `<th>${escapeHtml(c)}</th>`).join('')}</tr>`;

        queryResultBody.innerHTML = data.rows.map(row => `
            <tr>
                ${columns.map(col => `<td>${row[col] !== null ? escapeHtml(String(row[col])) : '<em style="color:#94a3b8;">NULL</em>'}</td>`).join('')}
            </tr>
        `).join('');
    } catch (err) {
        console.error('Query execution error:', err);
        queryResultBody.innerHTML = `<tr><td class="loading-state" style="color: #dc2626;">Execution Error: ${err.message}</td></tr>`;
    }
}

// Utility: HTML escaping
function escapeHtml(str) {
    if (str === null || str === undefined) return '';
    return String(str)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#39;');
}
