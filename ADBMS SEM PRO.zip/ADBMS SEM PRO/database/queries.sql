-- ============================================================================
-- ADBMS Project: E-Learning Management System (elearning_db)
-- Comprehensive SQL Demonstration Queries for ADBMS Course & Viva
-- ============================================================================

-- ============================================================================
-- QUERY 1: Basic SELECT
-- Retrieve all registered students ordered alphabetically by name
-- ============================================================================
SELECT 
    student_id, 
    name, 
    email, 
    phone, 
    department, 
    semester
FROM students
ORDER BY name ASC;

-- ============================================================================
-- QUERY 2: INNER JOIN
-- Retrieve courses along with their assigned instructor details
-- Demonstrates: 1:N relationship navigation between courses and instructors
-- ============================================================================
SELECT 
    c.course_id,
    c.course_name,
    c.category,
    i.name AS instructor_name,
    i.email AS instructor_email,
    i.department AS instructor_department
FROM courses c
INNER JOIN instructors i ON c.instructor_id = i.instructor_id
ORDER BY c.course_id;

-- ============================================================================
-- QUERY 3: Multi-table INNER JOIN
-- List all students enrolled in courses with their enrollment date and progress
-- Demonstrates: Navigating N:M relationship via bridge table (enrollments)
-- ============================================================================
SELECT 
    s.student_id,
    s.name AS student_name,
    c.course_id,
    c.course_name,
    e.enrollment_date,
    e.progress || '%' AS progress_percentage
FROM enrollments e
INNER JOIN students s ON e.student_id = s.student_id
INNER JOIN courses c ON e.course_id = c.course_id
ORDER BY c.course_name, s.name;

-- ============================================================================
-- QUERY 4: GROUP BY and COUNT()
-- Count the total number of students enrolled in each course
-- ============================================================================
SELECT 
    c.course_id,
    c.course_name,
    COUNT(e.student_id) AS total_enrolled_students
FROM courses c
LEFT JOIN enrollments e ON c.course_id = e.course_id
GROUP BY c.course_id, c.course_name
ORDER BY total_enrolled_students DESC;

-- ============================================================================
-- QUERY 5: Aggregate Function AVG() with GROUP BY
-- Calculate the average student progress for each course
-- ============================================================================
SELECT 
    c.course_id,
    c.course_name,
    ROUND(AVG(e.progress), 2) AS average_progress_percentage
FROM courses c
JOIN enrollments e ON c.course_id = e.course_id
GROUP BY c.course_id, c.course_name
ORDER BY average_progress_percentage DESC;

-- ============================================================================
-- QUERY 6: WHERE Filtering
-- Find students who have achieved more than 50% progress in any enrolled course
-- ============================================================================
SELECT 
    s.name AS student_name,
    c.course_name,
    e.progress
FROM enrollments e
JOIN students s ON e.student_id = s.student_id
JOIN courses c ON e.course_id = c.course_id
WHERE e.progress > 50
ORDER BY e.progress DESC;

-- ============================================================================
-- QUERY 7: INNER JOIN for Assignments & Courses
-- List all assignments with course title and due date
-- ============================================================================
SELECT 
    a.assignment_id,
    a.title AS assignment_title,
    c.course_name,
    a.due_date,
    a.max_marks
FROM assignments a
JOIN courses c ON a.course_id = c.course_id
ORDER BY a.due_date ASC;

-- ============================================================================
-- QUERY 8: Multiple JOINs across 4 Tables
-- Retrieve student submission details with assignment title and awarded marks
-- ============================================================================
SELECT 
    sub.submission_id,
    s.name AS student_name,
    c.course_name,
    a.title AS assignment_title,
    sub.marks AS marks_obtained,
    a.max_marks,
    ROUND((sub.marks::NUMERIC / a.max_marks::NUMERIC) * 100, 2) AS percentage_score
FROM submissions sub
JOIN assignments a ON sub.assignment_id = a.assignment_id
JOIN courses c ON a.course_id = c.course_id
JOIN students s ON sub.student_id = s.student_id
ORDER BY sub.submission_id;

-- ============================================================================
-- QUERY 9: Aggregate Functions MAX(), MIN(), AVG()
-- Find performance benchmarks for assignment submissions
-- ============================================================================
SELECT 
    a.assignment_id,
    a.title AS assignment_title,
    a.max_marks,
    MAX(sub.marks) AS highest_marks,
    MIN(sub.marks) AS lowest_marks,
    ROUND(AVG(sub.marks), 2) AS average_marks,
    COUNT(sub.submission_id) AS total_submissions
FROM assignments a
JOIN submissions sub ON a.assignment_id = sub.assignment_id
GROUP BY a.assignment_id, a.title, a.max_marks;

-- ============================================================================
-- QUERY 10: GROUP BY and COUNT() for Lessons
-- Number of lessons created under each course
-- ============================================================================
SELECT 
    c.course_id,
    c.course_name,
    COUNT(l.lesson_id) AS total_lessons
FROM courses c
LEFT JOIN lessons l ON c.course_id = l.course_id
GROUP BY c.course_id, c.course_name
ORDER BY c.course_id;

-- ============================================================================
-- QUERY 11: LEFT OUTER JOIN (Identifying records with no matching relations)
-- Find students who are NOT currently enrolled in any course
-- ============================================================================
SELECT 
    s.student_id,
    s.name AS student_name,
    s.email,
    s.department
FROM students s
LEFT JOIN enrollments e ON s.student_id = e.student_id
WHERE e.enrollment_id IS NULL;

-- ============================================================================
-- QUERY 12: GROUP BY with HAVING Clause
-- Find courses that have more than 2 enrolled students
-- ============================================================================
SELECT 
    c.course_id,
    c.course_name,
    COUNT(e.student_id) AS student_count
FROM courses c
JOIN enrollments e ON c.course_id = e.course_id
GROUP BY c.course_id, c.course_name
HAVING COUNT(e.student_id) > 2;

-- ============================================================================
-- QUERY 13: Subquery
-- Find courses whose enrollment count is strictly above the average enrollment count
-- ============================================================================
SELECT 
    c.course_id,
    c.course_name,
    COUNT(e.student_id) AS enrollment_count
FROM courses c
JOIN enrollments e ON c.course_id = e.course_id
GROUP BY c.course_id, c.course_name
HAVING COUNT(e.student_id) > (
    SELECT AVG(course_counts.cnt)
    FROM (
        SELECT COUNT(student_id) AS cnt
        FROM enrollments
        GROUP BY course_id
    ) AS course_counts
);

-- ============================================================================
-- QUERY 14: Querying the ADBMS View
-- Query the pre-defined view 'course_enrollment_details'
-- ============================================================================
SELECT 
    course_name,
    instructor,
    student,
    enrollment_date,
    progress
FROM course_enrollment_details
ORDER BY course_name, student;

-- ============================================================================
-- QUERY 15: Calling the ADBMS Stored Function
-- Execute get_course_enrollment_count() for all courses
-- ============================================================================
SELECT 
    course_id,
    course_name,
    get_course_enrollment_count(course_id) AS active_enrollments
FROM courses
ORDER BY active_enrollments DESC;
