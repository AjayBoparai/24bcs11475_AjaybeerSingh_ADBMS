-- ============================================================================
-- ADBMS Project: E-Learning Management System (elearning_db)
-- Sample Data Population
-- ============================================================================

-- Clean up any existing data (retaining schema structure)
TRUNCATE TABLE submissions, assignments, enrollments, lessons, courses, instructors, students RESTART IDENTITY CASCADE;

-- ============================================================================
-- 1. INSERT INSTRUCTORS (5 Instructors)
-- ============================================================================
INSERT INTO instructors (name, email, department) VALUES
('Dr. Alan Turing', 'alan.turing@university.edu', 'Computer Science'),
('Dr. Barbara Liskov', 'barbara.liskov@university.edu', 'Computer Science'),
('Dr. Edgar F. Codd', 'edgar.codd@university.edu', 'Information Technology'),
('Prof. Donald Knuth', 'donald.knuth@university.edu', 'Computer Science'),
('Dr. Grace Hopper', 'grace.hopper@university.edu', 'Information Technology');

-- ============================================================================
-- 2. INSERT STUDENTS (10 Students)
-- ============================================================================
INSERT INTO students (name, email, phone, department, semester) VALUES
('Aarav Sharma', 'aarav.sharma@student.edu', '+91 98765 43210', 'Computer Science', 5),
('Priya Patel', 'priya.patel@student.edu', '+91 98765 43211', 'Computer Science', 5),
('Rohan Verma', 'rohan.verma@student.edu', '+91 98765 43212', 'Information Technology', 3),
('Ananya Iyer', 'ananya.iyer@student.edu', '+91 98765 43213', 'Computer Science', 6),
('Vikram Singh', 'vikram.singh@student.edu', '+91 98765 43214', 'Electronics', 4),
('Sneha Reddy', 'sneha.reddy@student.edu', '+91 98765 43215', 'Information Technology', 5),
('Kavya Nair', 'kavya.nair@student.edu', '+91 98765 43216', 'Computer Science', 4),
('Aditya Joshi', 'aditya.joshi@student.edu', '+91 98765 43217', 'Electronics', 6),
('Pooja Mehta', 'pooja.mehta@student.edu', '+91 98765 43218', 'Information Technology', 3),
('Rahul Deshmukh', 'rahul.deshmukh@student.edu', '+91 98765 43219', 'Computer Science', 5);

-- ============================================================================
-- 3. INSERT COURSES (8 Courses)
-- ============================================================================
INSERT INTO courses (course_name, description, category, instructor_id) VALUES
('Database Management System', 'Relational database concepts, normalization, SQL, indexing, and transactions.', 'Core CS', 3),
('Data Structures', 'Arrays, linked lists, trees, graphs, sorting and searching algorithms.', 'Core CS', 4),
('Computer Networks', 'OSI model, TCP/IP protocol suite, routing algorithms, and network security.', 'Networking', 5),
('Java Programming', 'Object-oriented programming, inheritance, multithreading, and collections.', 'Programming', 2),
('Web Development', 'Frontend fundamentals, REST APIs, modern web frameworks, and backend integration.', 'Software Dev', 5),
('Python Programming', 'Syntax, data analysis, automation, and basic scientific computing in Python.', 'Programming', 1),
('Operating Systems', 'Process management, CPU scheduling, deadlocks, memory management, and file systems.', 'Core CS', 1),
('Artificial Intelligence', 'Search algorithms, knowledge representation, neural networks, and heuristics.', 'AI & ML', 1);

-- ============================================================================
-- 4. INSERT LESSONS (24 Lessons across 8 courses)
-- ============================================================================
INSERT INTO lessons (course_id, lesson_number, lesson_title, lesson_content) VALUES
-- DBMS (Course 1)
(1, 1, 'Introduction to RDBMS & ER Modeling', 'Overview of database systems, entity-relationship models, attributes, and cardinality.'),
(1, 2, 'Relational Algebra & SQL DDL/DML', 'Mathematical foundations of relational queries, schema definition, and manipulation.'),
(1, 3, 'Normalization: 1NF, 2NF, 3NF & BCNF', 'Decomposition techniques to eliminate update, insertion, and deletion anomalies.'),

-- Data Structures (Course 2)
(2, 1, 'Arrays and Linked Lists', 'Contiguous vs linked memory allocation, singly and doubly linked list operations.'),
(2, 2, 'Stacks, Queues, and Applications', 'LIFO and FIFO structures, postfix expression evaluation, queue simulations.'),
(2, 3, 'Trees and Binary Search Trees (BST)', 'Tree traversals (inorder, preorder, postorder), insertion and deletion in BST.'),

-- Computer Networks (Course 3)
(3, 1, 'Physical and Data Link Layers', 'Transmission media, framing, error detection using CRC, and flow control mechanisms.'),
(3, 2, 'Network Layer & IP Addressing', 'IPv4/IPv6 packet formats, subnets, CIDR notation, and Dijkstra routing algorithm.'),
(3, 3, 'Transport Layer (TCP & UDP)', 'Three-way handshake, reliable data transfer, congestion control, and windowing.'),

-- Java Programming (Course 4)
(4, 1, 'OOP Fundamentals in Java', 'Classes, objects, constructors, data encapsulation, and access specifiers.'),
(4, 2, 'Inheritance and Polymorphism', 'Method overriding vs overloading, abstract classes, and interface contracts.'),
(4, 3, 'Exception Handling & Multithreading', 'Try-catch-finally blocks, checked vs unchecked exceptions, and thread lifecycles.'),

-- Web Development (Course 5)
(5, 1, 'HTML5, CSS3, and Semantic Layouts', 'Document structure, CSS Grid, Flexbox, and responsive viewport design.'),
(5, 2, 'Client-Side JavaScript & DOM API', 'Event loop, asynchronous fetch calls, DOM manipulation, and dynamic table rendering.'),
(5, 3, 'Node.js and Express RESTful Services', 'Building HTTP endpoints, middleware routing, and JSON request/response pipelines.'),

-- Python Programming (Course 6)
(6, 1, 'Python Language Fundamentals', 'Dynamic typing, list comprehensions, tuples, dictionaries, and functional constructs.'),
(6, 2, 'File I/O and Exception Handling', 'Context managers with open(), reading/writing CSV files, and custom exceptions.'),
(6, 3, 'Modules, Packages & Virtual Environments', 'Package architecture, importing third-party modules, and venv isolation.'),

-- Operating Systems (Course 7)
(7, 1, 'Process Management & Scheduling', 'Process control blocks (PCB), context switching, FCFS, Round Robin, and SJF scheduling.'),
(7, 2, 'Process Synchronization & Deadlocks', 'Race conditions, semaphores, mutexes, Banker algorithm for deadlock avoidance.'),
(7, 3, 'Virtual Memory & Page Replacement', 'Paging, TLB, page faults, FIFO, LRU, and Optimal page replacement policies.'),

-- Artificial Intelligence (Course 8)
(8, 1, 'Intelligent Agents & Problem Solving', 'Agent architecture, state space search, Breadth-First, Depth-First, and A* search.'),
(8, 2, 'Adversarial Search & Game Playing', 'Minimax decision rule, Alpha-Beta pruning, and evaluation heuristics.'),
(8, 3, 'Knowledge Representation & Logic', 'Propositional logic, first-order predicate logic, inference rules, and resolution.');

-- ============================================================================
-- 5. INSERT ENROLLMENTS (15 Enrollments)
-- Resolves Student N to N Course with progress tracking
-- ============================================================================
INSERT INTO enrollments (student_id, course_id, enrollment_date, progress) VALUES
(1, 1, '2026-08-01', 85),  -- Aarav in DBMS
(1, 2, '2026-08-02', 70),  -- Aarav in Data Structures
(2, 1, '2026-08-01', 95),  -- Priya in DBMS
(2, 4, '2026-08-05', 60),  -- Priya in Java
(3, 3, '2026-08-03', 40),  -- Rohan in Networks
(3, 5, '2026-08-04', 55),  -- Rohan in Web Dev
(4, 1, '2026-08-02', 100), -- Ananya in DBMS
(4, 6, '2026-08-06', 80),  -- Ananya in Python
(5, 3, '2026-08-08', 30),  -- Vikram in Networks
(6, 5, '2026-08-07', 90),  -- Sneha in Web Dev
(6, 7, '2026-08-09', 45),  -- Sneha in OS
(7, 2, '2026-08-03', 65),  -- Kavya in Data Structures
(7, 8, '2026-08-10', 50),  -- Kavya in AI
(8, 7, '2026-08-11', 20),  -- Aditya in OS
(9, 6, '2026-08-12', 75);  -- Pooja in Python
-- Note: Student 10 (Rahul Deshmukh) is deliberately not enrolled yet to demonstrate LEFT JOIN queries for un-enrolled students!

-- ============================================================================
-- 6. INSERT ASSIGNMENTS (10 Assignments)
-- ============================================================================
INSERT INTO assignments (course_id, title, description, due_date, max_marks) VALUES
(1, 'ER Diagram & Normalization Case Study', 'Design an ER diagram for a hospital system and decompose it to 3NF.', '2026-09-15', 50),
(1, 'Complex SQL Query Optimization', 'Write and analyze queries using JOINs, aggregates, and subqueries.', '2026-09-30', 50),
(2, 'Balanced BST Implementation', 'Implement AVL tree insertion and rotation operations in C++/Java.', '2026-09-20', 100),
(2, 'Shortest Path Graph Algorithm', 'Implement Dijkstra algorithm on directed weighted graphs.', '2026-10-05', 100),
(3, 'Subnetting and Routing Simulation', 'Calculate network masks, broadcast addresses, and routing tables.', '2026-09-25', 50),
(4, 'Multithreaded Producer-Consumer Problem', 'Implement thread synchronization using wait(), notify(), and BlockingQueue.', '2026-09-28', 100),
(5, 'REST API with Express & PostgreSQL', 'Build a CRUD API with proper parameterized SQL and validation.', '2026-10-10', 100),
(6, 'Data Processing Pipeline with Pandas', 'Clean and summarize real-world sensor datasets.', '2026-10-12', 50),
(7, 'CPU Scheduling Simulator', 'Simulate Round-Robin and Priority scheduling with turnaround times.', '2026-10-15', 100),
(8, 'A* Pathfinding Grid Implementation', 'Find the optimal path in a 2D obstacle grid using Manhattan distance heuristic.', '2026-10-18', 100);

-- ============================================================================
-- 7. INSERT SUBMISSIONS (15 Submissions)
-- ============================================================================
INSERT INTO submissions (assignment_id, student_id, submission_date, marks) VALUES
(1, 1, '2026-09-14', 48),  -- Aarav in DBMS Assign 1
(1, 2, '2026-09-15', 50),  -- Priya in DBMS Assign 1
(1, 4, '2026-09-13', 49),  -- Ananya in DBMS Assign 1
(2, 1, '2026-09-29', 46),  -- Aarav in DBMS Assign 2
(2, 2, '2026-09-28', 47),  -- Priya in DBMS Assign 2
(3, 1, '2026-09-19', 92),  -- Aarav in DS Assign 1
(3, 7, '2026-09-20', 88),  -- Kavya in DS Assign 1
(5, 3, '2026-09-24', 42),  -- Rohan in Networks Assign 1
(5, 5, '2026-09-25', 38),  -- Vikram in Networks Assign 1
(6, 2, '2026-09-27', 95),  -- Priya in Java Assign 1
(7, 3, '2026-10-09', 85),  -- Rohan in Web Dev Assign 1
(7, 6, '2026-10-08', 98),  -- Sneha in Web Dev Assign 1
(8, 4, '2026-10-11', 47),  -- Ananya in Python Assign 1
(8, 9, '2026-10-12', 44),  -- Pooja in Python Assign 1
(9, 6, '2026-10-14', 91);  -- Sneha in OS Assign 1
