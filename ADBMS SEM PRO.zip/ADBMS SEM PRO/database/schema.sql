-- ============================================================================
-- ADBMS Project: E-Learning Management System (elearning_db)
-- Database Schema Definition with Constraints, Indexes, View, Function & Trigger
-- ============================================================================

-- Drop dependent objects if they exist for clean re-initialization
DROP VIEW IF EXISTS course_enrollment_details;
DROP TRIGGER IF EXISTS trg_check_enrollment_progress ON enrollments;
DROP FUNCTION IF EXISTS check_enrollment_progress();
DROP FUNCTION IF EXISTS get_course_enrollment_count(INT);

DROP TABLE IF EXISTS submissions CASCADE;
DROP TABLE IF EXISTS assignments CASCADE;
DROP TABLE IF EXISTS enrollments CASCADE;
DROP TABLE IF EXISTS lessons CASCADE;
DROP TABLE IF EXISTS courses CASCADE;
DROP TABLE IF EXISTS instructors CASCADE;
DROP TABLE IF EXISTS students CASCADE;

-- ============================================================================
-- 1. STUDENTS TABLE
-- ============================================================================
CREATE TABLE students (
    student_id SERIAL PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    phone VARCHAR(20),
    department VARCHAR(50) NOT NULL,
    semester INT NOT NULL CHECK (semester >= 1 AND semester <= 8)
);

-- ============================================================================
-- 2. INSTRUCTORS TABLE
-- ============================================================================
CREATE TABLE instructors (
    instructor_id SERIAL PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    department VARCHAR(50) NOT NULL
);

-- ============================================================================
-- 3. COURSES TABLE
-- Relationship: Instructor 1 --> N Courses
-- ============================================================================
CREATE TABLE courses (
    course_id SERIAL PRIMARY KEY,
    course_name VARCHAR(150) NOT NULL,
    description TEXT,
    category VARCHAR(50) NOT NULL,
    instructor_id INT NOT NULL,
    CONSTRAINT fk_courses_instructor
        FOREIGN KEY (instructor_id) 
        REFERENCES instructors(instructor_id)
        ON UPDATE CASCADE
        ON DELETE RESTRICT
);

-- ============================================================================
-- 4. LESSONS TABLE
-- Relationship: Course 1 --> N Lessons
-- ============================================================================
CREATE TABLE lessons (
    lesson_id SERIAL PRIMARY KEY,
    course_id INT NOT NULL,
    lesson_title VARCHAR(150) NOT NULL,
    lesson_content TEXT,
    lesson_number INT NOT NULL CHECK (lesson_number > 0),
    CONSTRAINT fk_lessons_course
        FOREIGN KEY (course_id) 
        REFERENCES courses(course_id)
        ON UPDATE CASCADE
        ON DELETE CASCADE
);

-- ============================================================================
-- 5. ENROLLMENTS TABLE (Resolves Student N to N Course)
-- Relationship: Student N --> N Course
-- ============================================================================
CREATE TABLE enrollments (
    enrollment_id SERIAL PRIMARY KEY,
    student_id INT NOT NULL,
    course_id INT NOT NULL,
    enrollment_date DATE NOT NULL DEFAULT CURRENT_DATE,
    progress INT NOT NULL DEFAULT 0 CHECK (progress >= 0 AND progress <= 100),
    CONSTRAINT fk_enrollments_student
        FOREIGN KEY (student_id) 
        REFERENCES students(student_id)
        ON UPDATE CASCADE
        ON DELETE CASCADE,
    CONSTRAINT fk_enrollments_course
        FOREIGN KEY (course_id) 
        REFERENCES courses(course_id)
        ON UPDATE CASCADE
        ON DELETE CASCADE,
    CONSTRAINT uq_student_course 
        UNIQUE (student_id, course_id)
);

-- ============================================================================
-- 6. ASSIGNMENTS TABLE
-- Relationship: Course 1 --> N Assignments
-- ============================================================================
CREATE TABLE assignments (
    assignment_id SERIAL PRIMARY KEY,
    course_id INT NOT NULL,
    title VARCHAR(150) NOT NULL,
    description TEXT,
    due_date DATE NOT NULL,
    max_marks INT NOT NULL CHECK (max_marks > 0),
    CONSTRAINT fk_assignments_course
        FOREIGN KEY (course_id) 
        REFERENCES courses(course_id)
        ON UPDATE CASCADE
        ON DELETE CASCADE
);

-- ============================================================================
-- 7. SUBMISSIONS TABLE
-- Relationships:
-- Assignment 1 --> N Submissions
-- Student 1 --> N Submissions
-- ============================================================================
CREATE TABLE submissions (
    submission_id SERIAL PRIMARY KEY,
    assignment_id INT NOT NULL,
    student_id INT NOT NULL,
    submission_date DATE NOT NULL DEFAULT CURRENT_DATE,
    marks INT CHECK (marks >= 0),
    CONSTRAINT fk_submissions_assignment
        FOREIGN KEY (assignment_id) 
        REFERENCES assignments(assignment_id)
        ON UPDATE CASCADE
        ON DELETE CASCADE,
    CONSTRAINT fk_submissions_student
        FOREIGN KEY (student_id) 
        REFERENCES students(student_id)
        ON UPDATE CASCADE
        ON DELETE CASCADE,
    CONSTRAINT uq_student_assignment
        UNIQUE (student_id, assignment_id)
);

-- ============================================================================
-- INDEXES (Optimizing Foreign Key Lookups & Unique Searches)
-- ============================================================================
CREATE INDEX idx_students_email ON students(email);
CREATE INDEX idx_courses_instructor_id ON courses(instructor_id);
CREATE INDEX idx_enrollments_student_id ON enrollments(student_id);
CREATE INDEX idx_enrollments_course_id ON enrollments(course_id);
CREATE INDEX idx_lessons_course_id ON lessons(course_id);
CREATE INDEX idx_assignments_course_id ON assignments(course_id);
CREATE INDEX idx_submissions_assignment_id ON submissions(assignment_id);
CREATE INDEX idx_submissions_student_id ON submissions(student_id);

-- ============================================================================
-- ADVANCED ADBMS FEATURE 1: VIEW
-- course_enrollment_details: Combines course, instructor, student, and progress
-- ============================================================================
CREATE OR REPLACE VIEW course_enrollment_details AS
SELECT 
    c.course_name,
    i.name AS instructor,
    s.name AS student,
    e.enrollment_date,
    e.progress
FROM enrollments e
JOIN courses c ON e.course_id = c.course_id
JOIN instructors i ON c.instructor_id = i.instructor_id
JOIN students s ON e.student_id = s.student_id;

-- ============================================================================
-- ADVANCED ADBMS FEATURE 2: STORED FUNCTION (PL/pgSQL)
-- Returns the total count of enrolled students for a specific course ID
-- ============================================================================
CREATE OR REPLACE FUNCTION get_course_enrollment_count(p_course_id INT)
RETURNS INT AS $$
DECLARE
    v_count INT;
BEGIN
    SELECT COUNT(*) INTO v_count
    FROM enrollments
    WHERE course_id = p_course_id;
    RETURN v_count;
END;
$$ LANGUAGE plpgsql;

-- ============================================================================
-- ADVANCED ADBMS FEATURE 3: TRIGGER & TRIGGER FUNCTION
-- Validates that the progress value is strictly between 0 and 100 before save
-- ============================================================================
CREATE OR REPLACE FUNCTION check_enrollment_progress()
RETURNS TRIGGER AS $$
BEGIN
    IF NEW.progress < 0 OR NEW.progress > 100 THEN
        RAISE EXCEPTION 'Invalid progress value: %. Progress must be between 0 and 100.', NEW.progress;
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_check_enrollment_progress
BEFORE INSERT OR UPDATE ON enrollments
FOR EACH ROW
EXECUTE FUNCTION check_enrollment_progress();
